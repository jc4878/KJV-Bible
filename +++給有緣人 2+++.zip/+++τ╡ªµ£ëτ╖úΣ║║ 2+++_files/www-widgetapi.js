(function(){/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
'use strict';var p;function aa(a){var b=0;return function(){return b<a.length?{done:!1,value:a[b++]}:{done:!0}}}
var ba="function"==typeof Object.defineProperties?Object.defineProperty:function(a,b,c){if(a==Array.prototype||a==Object.prototype)return a;a[b]=c.value;return a};
function ca(a){a=["object"==typeof globalThis&&globalThis,a,"object"==typeof window&&window,"object"==typeof self&&self,"object"==typeof global&&global];for(var b=0;b<a.length;++b){var c=a[b];if(c&&c.Math==Math)return c}throw Error("Cannot find global object");}
var da=ca(this);function t(a,b){if(b)a:{var c=da;a=a.split(".");for(var d=0;d<a.length-1;d++){var e=a[d];if(!(e in c))break a;c=c[e]}a=a[a.length-1];d=c[a];b=b(d);b!=d&&null!=b&&ba(c,a,{configurable:!0,writable:!0,value:b})}}
t("Symbol",function(a){function b(e){if(this instanceof b)throw new TypeError("Symbol is not a constructor");return new c("jscomp_symbol_"+(e||"")+"_"+d++,e)}
function c(e,f){this.h=e;ba(this,"description",{configurable:!0,writable:!0,value:f})}
if(a)return a;c.prototype.toString=function(){return this.h};
var d=0;return b});
t("Symbol.iterator",function(a){if(a)return a;a=Symbol("Symbol.iterator");for(var b="Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "),c=0;c<b.length;c++){var d=da[b[c]];"function"===typeof d&&"function"!=typeof d.prototype[a]&&ba(d.prototype,a,{configurable:!0,writable:!0,value:function(){return ea(aa(this))}})}return a});
function ea(a){a={next:a};a[Symbol.iterator]=function(){return this};
return a}
function u(a){var b="undefined"!=typeof Symbol&&Symbol.iterator&&a[Symbol.iterator];return b?b.call(a):{next:aa(a)}}
var fa="function"==typeof Object.create?Object.create:function(a){function b(){}
b.prototype=a;return new b},ha;
if("function"==typeof Object.setPrototypeOf)ha=Object.setPrototypeOf;else{var ia;a:{var ja={a:!0},ka={};try{ka.__proto__=ja;ia=ka.a;break a}catch(a){}ia=!1}ha=ia?function(a,b){a.__proto__=b;if(a.__proto__!==b)throw new TypeError(a+" is not extensible");return a}:null}var la=ha;
function ma(a,b){a.prototype=fa(b.prototype);a.prototype.constructor=a;if(la)la(a,b);else for(var c in b)if("prototype"!=c)if(Object.defineProperties){var d=Object.getOwnPropertyDescriptor(b,c);d&&Object.defineProperty(a,c,d)}else a[c]=b[c];a.D=b.prototype}
function na(){this.o=!1;this.l=null;this.j=void 0;this.h=1;this.m=this.s=0;this.B=this.i=null}
function pa(a){if(a.o)throw new TypeError("Generator is already running");a.o=!0}
na.prototype.v=function(a){this.j=a};
function qa(a,b){a.i={fa:b,ga:!0};a.h=a.s||a.m}
na.prototype.return=function(a){this.i={return:a};this.h=this.m};
function x(a,b,c){a.h=c;return{value:b}}
na.prototype.u=function(a){this.h=a};
function ra(a,b,c){a.s=b;void 0!=c&&(a.m=c)}
function sa(a){a.s=0;var b=a.i.fa;a.i=null;return b}
function ta(a){a.B=[a.i];a.s=0;a.m=0}
function ua(a){var b=a.B.splice(0)[0];(b=a.i=a.i||b)?b.ga?a.h=a.s||a.m:void 0!=b.u&&a.m<b.u?(a.h=b.u,a.i=null):a.h=a.m:a.h=0}
function va(a){this.h=new na;this.i=a}
function wa(a,b){pa(a.h);var c=a.h.l;if(c)return xa(a,"return"in c?c["return"]:function(d){return{value:d,done:!0}},b,a.h.return);
a.h.return(b);return ya(a)}
function xa(a,b,c,d){try{var e=b.call(a.h.l,c);if(!(e instanceof Object))throw new TypeError("Iterator result "+e+" is not an object");if(!e.done)return a.h.o=!1,e;var f=e.value}catch(g){return a.h.l=null,qa(a.h,g),ya(a)}a.h.l=null;d.call(a.h,f);return ya(a)}
function ya(a){for(;a.h.h;)try{var b=a.i(a.h);if(b)return a.h.o=!1,{value:b.value,done:!1}}catch(c){a.h.j=void 0,qa(a.h,c)}a.h.o=!1;if(a.h.i){b=a.h.i;a.h.i=null;if(b.ga)throw b.fa;return{value:b.return,done:!0}}return{value:void 0,done:!0}}
function za(a){this.next=function(b){pa(a.h);a.h.l?b=xa(a,a.h.l.next,b,a.h.v):(a.h.v(b),b=ya(a));return b};
this.throw=function(b){pa(a.h);a.h.l?b=xa(a,a.h.l["throw"],b,a.h.v):(qa(a.h,b),b=ya(a));return b};
this.return=function(b){return wa(a,b)};
this[Symbol.iterator]=function(){return this}}
function z(a,b){b=new za(new va(b));la&&a.prototype&&la(b,a.prototype);return b}
t("Reflect.setPrototypeOf",function(a){return a?a:la?function(b,c){try{return la(b,c),!0}catch(d){return!1}}:null});
function Aa(a,b,c){if(null==a)throw new TypeError("The 'this' value for String.prototype."+c+" must not be null or undefined");if(b instanceof RegExp)throw new TypeError("First argument to String.prototype."+c+" must not be a regular expression");return a+""}
t("String.prototype.endsWith",function(a){return a?a:function(b,c){var d=Aa(this,b,"endsWith");b+="";void 0===c&&(c=d.length);c=Math.max(0,Math.min(c|0,d.length));for(var e=b.length;0<e&&0<c;)if(d[--c]!=b[--e])return!1;return 0>=e}});
t("String.prototype.startsWith",function(a){return a?a:function(b,c){var d=Aa(this,b,"startsWith");b+="";var e=d.length,f=b.length;c=Math.max(0,Math.min(c|0,d.length));for(var g=0;g<f&&c<e;)if(d[c++]!=b[g++])return!1;return g>=f}});
t("Object.setPrototypeOf",function(a){return a||la});
function A(a,b){return Object.prototype.hasOwnProperty.call(a,b)}
var Ba="function"==typeof Object.assign?Object.assign:function(a,b){for(var c=1;c<arguments.length;c++){var d=arguments[c];if(d)for(var e in d)A(d,e)&&(a[e]=d[e])}return a};
t("Object.assign",function(a){return a||Ba});
t("Promise",function(a){function b(g){this.h=0;this.j=void 0;this.i=[];this.o=!1;var h=this.l();try{g(h.resolve,h.reject)}catch(k){h.reject(k)}}
function c(){this.h=null}
function d(g){return g instanceof b?g:new b(function(h){h(g)})}
if(a)return a;c.prototype.i=function(g){if(null==this.h){this.h=[];var h=this;this.j(function(){h.m()})}this.h.push(g)};
var e=da.setTimeout;c.prototype.j=function(g){e(g,0)};
c.prototype.m=function(){for(;this.h&&this.h.length;){var g=this.h;this.h=[];for(var h=0;h<g.length;++h){var k=g[h];g[h]=null;try{k()}catch(l){this.l(l)}}}this.h=null};
c.prototype.l=function(g){this.j(function(){throw g;})};
b.prototype.l=function(){function g(l){return function(m){k||(k=!0,l.call(h,m))}}
var h=this,k=!1;return{resolve:g(this.S),reject:g(this.m)}};
b.prototype.S=function(g){if(g===this)this.m(new TypeError("A Promise cannot resolve to itself"));else if(g instanceof b)this.Z(g);else{a:switch(typeof g){case "object":var h=null!=g;break a;case "function":h=!0;break a;default:h=!1}h?this.N(g):this.s(g)}};
b.prototype.N=function(g){var h=void 0;try{h=g.then}catch(k){this.m(k);return}"function"==typeof h?this.ma(h,g):this.s(g)};
b.prototype.m=function(g){this.v(2,g)};
b.prototype.s=function(g){this.v(1,g)};
b.prototype.v=function(g,h){if(0!=this.h)throw Error("Cannot settle("+g+", "+h+"): Promise already settled in state"+this.h);this.h=g;this.j=h;2===this.h&&this.Y();this.B()};
b.prototype.Y=function(){var g=this;e(function(){if(g.J()){var h=da.console;"undefined"!==typeof h&&h.error(g.j)}},1)};
b.prototype.J=function(){if(this.o)return!1;var g=da.CustomEvent,h=da.Event,k=da.dispatchEvent;if("undefined"===typeof k)return!0;"function"===typeof g?g=new g("unhandledrejection",{cancelable:!0}):"function"===typeof h?g=new h("unhandledrejection",{cancelable:!0}):(g=da.document.createEvent("CustomEvent"),g.initCustomEvent("unhandledrejection",!1,!0,g));g.promise=this;g.reason=this.j;return k(g)};
b.prototype.B=function(){if(null!=this.i){for(var g=0;g<this.i.length;++g)f.i(this.i[g]);this.i=null}};
var f=new c;b.prototype.Z=function(g){var h=this.l();g.U(h.resolve,h.reject)};
b.prototype.ma=function(g,h){var k=this.l();try{g.call(h,k.resolve,k.reject)}catch(l){k.reject(l)}};
b.prototype.then=function(g,h){function k(r,q){return"function"==typeof r?function(v){try{l(r(v))}catch(w){m(w)}}:q}
var l,m,n=new b(function(r,q){l=r;m=q});
this.U(k(g,l),k(h,m));return n};
b.prototype.catch=function(g){return this.then(void 0,g)};
b.prototype.U=function(g,h){function k(){switch(l.h){case 1:g(l.j);break;case 2:h(l.j);break;default:throw Error("Unexpected state: "+l.h);}}
var l=this;null==this.i?f.i(k):this.i.push(k);this.o=!0};
b.resolve=d;b.reject=function(g){return new b(function(h,k){k(g)})};
b.race=function(g){return new b(function(h,k){for(var l=u(g),m=l.next();!m.done;m=l.next())d(m.value).U(h,k)})};
b.all=function(g){var h=u(g),k=h.next();return k.done?d([]):new b(function(l,m){function n(v){return function(w){r[v]=w;q--;0==q&&l(r)}}
var r=[],q=0;do r.push(void 0),q++,d(k.value).U(n(r.length-1),m),k=h.next();while(!k.done)})};
return b});
t("Object.is",function(a){return a?a:function(b,c){return b===c?0!==b||1/b===1/c:b!==b&&c!==c}});
t("Array.prototype.includes",function(a){return a?a:function(b,c){var d=this;d instanceof String&&(d=String(d));var e=d.length;c=c||0;for(0>c&&(c=Math.max(c+e,0));c<e;c++){var f=d[c];if(f===b||Object.is(f,b))return!0}return!1}});
t("String.prototype.includes",function(a){return a?a:function(b,c){return-1!==Aa(this,b,"includes").indexOf(b,c||0)}});
t("Object.entries",function(a){return a?a:function(b){var c=[],d;for(d in b)A(b,d)&&c.push([d,b[d]]);return c}});
t("WeakMap",function(a){function b(k){this.h=(h+=Math.random()+1).toString();if(k){k=u(k);for(var l;!(l=k.next()).done;)l=l.value,this.set(l[0],l[1])}}
function c(){}
function d(k){var l=typeof k;return"object"===l&&null!==k||"function"===l}
function e(k){if(!A(k,g)){var l=new c;ba(k,g,{value:l})}}
function f(k){var l=Object[k];l&&(Object[k]=function(m){if(m instanceof c)return m;Object.isExtensible(m)&&e(m);return l(m)})}
if(function(){if(!a||!Object.seal)return!1;try{var k=Object.seal({}),l=Object.seal({}),m=new a([[k,2],[l,3]]);if(2!=m.get(k)||3!=m.get(l))return!1;m.delete(k);m.set(l,4);return!m.has(k)&&4==m.get(l)}catch(n){return!1}}())return a;
var g="$jscomp_hidden_"+Math.random();f("freeze");f("preventExtensions");f("seal");var h=0;b.prototype.set=function(k,l){if(!d(k))throw Error("Invalid WeakMap key");e(k);if(!A(k,g))throw Error("WeakMap key fail: "+k);k[g][this.h]=l;return this};
b.prototype.get=function(k){return d(k)&&A(k,g)?k[g][this.h]:void 0};
b.prototype.has=function(k){return d(k)&&A(k,g)&&A(k[g],this.h)};
b.prototype.delete=function(k){return d(k)&&A(k,g)&&A(k[g],this.h)?delete k[g][this.h]:!1};
return b});
t("Map",function(a){function b(){var h={};return h.previous=h.next=h.head=h}
function c(h,k){var l=h.h;return ea(function(){if(l){for(;l.head!=h.h;)l=l.previous;for(;l.next!=l.head;)return l=l.next,{done:!1,value:k(l)};l=null}return{done:!0,value:void 0}})}
function d(h,k){var l=k&&typeof k;"object"==l||"function"==l?f.has(k)?l=f.get(k):(l=""+ ++g,f.set(k,l)):l="p_"+k;var m=h.i[l];if(m&&A(h.i,l))for(h=0;h<m.length;h++){var n=m[h];if(k!==k&&n.key!==n.key||k===n.key)return{id:l,list:m,index:h,A:n}}return{id:l,list:m,index:-1,A:void 0}}
function e(h){this.i={};this.h=b();this.size=0;if(h){h=u(h);for(var k;!(k=h.next()).done;)k=k.value,this.set(k[0],k[1])}}
if(function(){if(!a||"function"!=typeof a||!a.prototype.entries||"function"!=typeof Object.seal)return!1;try{var h=Object.seal({x:4}),k=new a(u([[h,"s"]]));if("s"!=k.get(h)||1!=k.size||k.get({x:4})||k.set({x:4},"t")!=k||2!=k.size)return!1;var l=k.entries(),m=l.next();if(m.done||m.value[0]!=h||"s"!=m.value[1])return!1;m=l.next();return m.done||4!=m.value[0].x||"t"!=m.value[1]||!l.next().done?!1:!0}catch(n){return!1}}())return a;
var f=new WeakMap;e.prototype.set=function(h,k){h=0===h?0:h;var l=d(this,h);l.list||(l.list=this.i[l.id]=[]);l.A?l.A.value=k:(l.A={next:this.h,previous:this.h.previous,head:this.h,key:h,value:k},l.list.push(l.A),this.h.previous.next=l.A,this.h.previous=l.A,this.size++);return this};
e.prototype.delete=function(h){h=d(this,h);return h.A&&h.list?(h.list.splice(h.index,1),h.list.length||delete this.i[h.id],h.A.previous.next=h.A.next,h.A.next.previous=h.A.previous,h.A.head=null,this.size--,!0):!1};
e.prototype.clear=function(){this.i={};this.h=this.h.previous=b();this.size=0};
e.prototype.has=function(h){return!!d(this,h).A};
e.prototype.get=function(h){return(h=d(this,h).A)&&h.value};
e.prototype.entries=function(){return c(this,function(h){return[h.key,h.value]})};
e.prototype.keys=function(){return c(this,function(h){return h.key})};
e.prototype.values=function(){return c(this,function(h){return h.value})};
e.prototype.forEach=function(h,k){for(var l=this.entries(),m;!(m=l.next()).done;)m=m.value,h.call(k,m[1],m[0],this)};
e.prototype[Symbol.iterator]=e.prototype.entries;var g=0;return e});
t("Set",function(a){function b(c){this.h=new Map;if(c){c=u(c);for(var d;!(d=c.next()).done;)this.add(d.value)}this.size=this.h.size}
if(function(){if(!a||"function"!=typeof a||!a.prototype.entries||"function"!=typeof Object.seal)return!1;try{var c=Object.seal({x:4}),d=new a(u([c]));if(!d.has(c)||1!=d.size||d.add(c)!=d||1!=d.size||d.add({x:4})!=d||2!=d.size)return!1;var e=d.entries(),f=e.next();if(f.done||f.value[0]!=c||f.value[1]!=c)return!1;f=e.next();return f.done||f.value[0]==c||4!=f.value[0].x||f.value[1]!=f.value[0]?!1:e.next().done}catch(g){return!1}}())return a;
b.prototype.add=function(c){c=0===c?0:c;this.h.set(c,c);this.size=this.h.size;return this};
b.prototype.delete=function(c){c=this.h.delete(c);this.size=this.h.size;return c};
b.prototype.clear=function(){this.h.clear();this.size=0};
b.prototype.has=function(c){return this.h.has(c)};
b.prototype.entries=function(){return this.h.entries()};
b.prototype.values=function(){return this.h.values()};
b.prototype.keys=b.prototype.values;b.prototype[Symbol.iterator]=b.prototype.values;b.prototype.forEach=function(c,d){var e=this;this.h.forEach(function(f){return c.call(d,f,f,e)})};
return b});
function Ca(a,b){a instanceof String&&(a+="");var c=0,d=!1,e={next:function(){if(!d&&c<a.length){var f=c++;return{value:b(f,a[f]),done:!1}}d=!0;return{done:!0,value:void 0}}};
e[Symbol.iterator]=function(){return e};
return e}
t("Array.prototype.entries",function(a){return a?a:function(){return Ca(this,function(b,c){return[b,c]})}});
t("Array.prototype.keys",function(a){return a?a:function(){return Ca(this,function(b){return b})}});
t("Array.prototype.values",function(a){return a?a:function(){return Ca(this,function(b,c){return c})}});
t("Number.isNaN",function(a){return a?a:function(b){return"number"===typeof b&&isNaN(b)}});
t("Number.MAX_SAFE_INTEGER",function(){return 9007199254740991});
var B=this||self;function D(a,b){a=a.split(".");b=b||B;for(var c=0;c<a.length;c++)if(b=b[a[c]],null==b)return null;return b}
function Da(){}
function Ea(a){var b=typeof a;b="object"!=b?b:a?Array.isArray(a)?"array":b:"null";return"array"==b||"object"==b&&"number"==typeof a.length}
function E(a){var b=typeof a;return"object"==b&&null!=a||"function"==b}
function Fa(a){return Object.prototype.hasOwnProperty.call(a,Ga)&&a[Ga]||(a[Ga]=++Ha)}
var Ga="closure_uid_"+(1E9*Math.random()>>>0),Ha=0;function Ia(a,b,c){return a.call.apply(a.bind,arguments)}
function Ja(a,b,c){if(!a)throw Error();if(2<arguments.length){var d=Array.prototype.slice.call(arguments,2);return function(){var e=Array.prototype.slice.call(arguments);Array.prototype.unshift.apply(e,d);return a.apply(b,e)}}return function(){return a.apply(b,arguments)}}
function Ka(a,b,c){Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?Ka=Ia:Ka=Ja;return Ka.apply(null,arguments)}
function F(a,b){a=a.split(".");var c=B;a[0]in c||"undefined"==typeof c.execScript||c.execScript("var "+a[0]);for(var d;a.length&&(d=a.shift());)a.length||void 0===b?c[d]&&c[d]!==Object.prototype[d]?c=c[d]:c=c[d]={}:c[d]=b}
function G(a,b){function c(){}
c.prototype=b.prototype;a.D=b.prototype;a.prototype=new c;a.prototype.constructor=a;a.Qa=function(d,e,f){for(var g=Array(arguments.length-2),h=2;h<arguments.length;h++)g[h-2]=arguments[h];return b.prototype[e].apply(d,g)}}
function La(a){return a}
;function Ma(a,b){if(Error.captureStackTrace)Error.captureStackTrace(this,Ma);else{var c=Error().stack;c&&(this.stack=c)}a&&(this.message=String(a));b&&(this.pa=b)}
G(Ma,Error);Ma.prototype.name="CustomError";function Na(a){a=a.url;var b=/[?&]dsh=1(&|$)/.test(a);this.j=!b&&/[?&]ae=1(&|$)/.test(a);this.l=!b&&/[?&]ae=2(&|$)/.test(a);if((this.h=/[?&]adurl=([^&]*)/.exec(a))&&this.h[1]){try{var c=decodeURIComponent(this.h[1])}catch(d){c=null}this.i=c}}
;function Oa(a){var b=!1,c;return function(){b||(c=a(),b=!0);return c}}
;var Pa=Array.prototype.indexOf?function(a,b){return Array.prototype.indexOf.call(a,b,void 0)}:function(a,b){if("string"===typeof a)return"string"!==typeof b||1!=b.length?-1:a.indexOf(b,0);
for(var c=0;c<a.length;c++)if(c in a&&a[c]===b)return c;return-1},H=Array.prototype.forEach?function(a,b,c){Array.prototype.forEach.call(a,b,c)}:function(a,b,c){for(var d=a.length,e="string"===typeof a?a.split(""):a,f=0;f<d;f++)f in e&&b.call(c,e[f],f,a)},Qa=Array.prototype.reduce?function(a,b,c){return Array.prototype.reduce.call(a,b,c)}:function(a,b,c){var d=c;
H(a,function(e,f){d=b.call(void 0,d,e,f,a)});
return d};
function Ra(a,b){a:{for(var c=a.length,d="string"===typeof a?a.split(""):a,e=0;e<c;e++)if(e in d&&b.call(void 0,d[e],e,a)){b=e;break a}b=-1}return 0>b?null:"string"===typeof a?a.charAt(b):a[b]}
function Sa(a,b){b=Pa(a,b);var c;(c=0<=b)&&Array.prototype.splice.call(a,b,1);return c}
function Ta(a){return Array.prototype.concat.apply([],arguments)}
function Ua(a){var b=a.length;if(0<b){for(var c=Array(b),d=0;d<b;d++)c[d]=a[d];return c}return[]}
function Va(a,b){for(var c=1;c<arguments.length;c++){var d=arguments[c];if(Ea(d)){var e=a.length||0,f=d.length||0;a.length=e+f;for(var g=0;g<f;g++)a[e+g]=d[g]}else a.push(d)}}
;function Wa(a,b){for(var c in a)b.call(void 0,a[c],c,a)}
function Xa(a){var b=Ya,c;for(c in b)if(a.call(void 0,b[c],c,b))return c}
function Za(a,b){for(var c in a)if(!(c in b)||a[c]!==b[c])return!1;for(var d in b)if(!(d in a))return!1;return!0}
function $a(a){if(!a||"object"!==typeof a)return a;if("function"===typeof a.clone)return a.clone();var b=Array.isArray(a)?[]:"function"!==typeof ArrayBuffer||"function"!==typeof ArrayBuffer.isView||!ArrayBuffer.isView(a)||a instanceof DataView?{}:new a.constructor(a.length),c;for(c in a)b[c]=$a(a[c]);return b}
var ab="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function bb(a,b){for(var c,d,e=1;e<arguments.length;e++){d=arguments[e];for(c in d)a[c]=d[c];for(var f=0;f<ab.length;f++)c=ab[f],Object.prototype.hasOwnProperty.call(d,c)&&(a[c]=d[c])}}
;var cb;var db=String.prototype.trim?function(a){return a.trim()}:function(a){return/^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]},eb=/&/g,fb=/</g,gb=/>/g,hb=/"/g,ib=/'/g,jb=/\x00/g,kb=/[\x00&<>"']/;var lb;a:{var mb=B.navigator;if(mb){var nb=mb.userAgent;if(nb){lb=nb;break a}}lb=""}function J(a){return-1!=lb.indexOf(a)}
;function ob(a){this.h=pb===pb?a:""}
ob.prototype.toString=function(){return this.h.toString()};
var pb={};var qb=/^(?:([^:/?#.]+):)?(?:\/\/(?:([^\\/?#]*)@)?([^\\/?#]*?)(?::([0-9]+))?(?=[\\/?#]|$))?([^?#]+)?(?:\?([^#]*))?(?:#([\s\S]*))?$/;function rb(a){return a?decodeURI(a):a}
function sb(a){return rb(a.match(qb)[3]||null)}
function tb(a){var b=a.match(qb);a=b[1];var c=b[2],d=b[3];b=b[4];var e="";a&&(e+=a+":");d&&(e+="//",c&&(e+=c+"@"),e+=d,b&&(e+=":"+b));return e}
function ub(a,b,c){if(Array.isArray(b))for(var d=0;d<b.length;d++)ub(a,String(b[d]),c);else null!=b&&c.push(a+(""===b?"":"="+encodeURIComponent(String(b))))}
function vb(a){var b=[],c;for(c in a)ub(c,a[c],b);return b.join("&")}
var wb=/#|$/;function xb(a,b){var c=a.search(wb);a:{var d=0;for(var e=b.length;0<=(d=a.indexOf(b,d))&&d<c;){var f=a.charCodeAt(d-1);if(38==f||63==f)if(f=a.charCodeAt(d+e),!f||61==f||38==f||35==f)break a;d+=e+1}d=-1}if(0>d)return null;e=a.indexOf("&",d);if(0>e||e>c)e=c;d+=b.length+1;return decodeURIComponent(a.substr(d,e-d).replace(/\+/g," "))}
;function L(a,b){var c=void 0;return new (c||(c=Promise))(function(d,e){function f(k){try{h(b.next(k))}catch(l){e(l)}}
function g(k){try{h(b["throw"](k))}catch(l){e(l)}}
function h(k){k.done?d(k.value):(new c(function(l){l(k.value)})).then(f,g)}
h((b=b.apply(a,void 0)).next())})}
;function yb(){return J("iPhone")&&!J("iPod")&&!J("iPad")}
;function zb(a){zb[" "](a);return a}
zb[" "]=Da;var Ab=J("Opera"),Bb=J("Trident")||J("MSIE"),Cb=J("Edge"),Db=J("Gecko")&&!(-1!=lb.toLowerCase().indexOf("webkit")&&!J("Edge"))&&!(J("Trident")||J("MSIE"))&&!J("Edge"),Eb=-1!=lb.toLowerCase().indexOf("webkit")&&!J("Edge");function Fb(){var a=B.document;return a?a.documentMode:void 0}
var Gb;a:{var Hb="",Ib=function(){var a=lb;if(Db)return/rv:([^\);]+)(\)|;)/.exec(a);if(Cb)return/Edge\/([\d\.]+)/.exec(a);if(Bb)return/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);if(Eb)return/WebKit\/(\S+)/.exec(a);if(Ab)return/(?:Version)[ \/]?(\S+)/.exec(a)}();
Ib&&(Hb=Ib?Ib[1]:"");if(Bb){var Jb=Fb();if(null!=Jb&&Jb>parseFloat(Hb)){Gb=String(Jb);break a}}Gb=Hb}var Kb=Gb,Lb;if(B.document&&Bb){var Mb=Fb();Lb=Mb?Mb:parseInt(Kb,10)||void 0}else Lb=void 0;var Nb=Lb;var Ob=yb()||J("iPod"),Pb=J("iPad"),Qb=J("Safari")&&!((J("Chrome")||J("CriOS"))&&!J("Edge")||J("Coast")||J("Opera")||J("Edge")||J("Edg/")||J("OPR")||J("Firefox")||J("FxiOS")||J("Silk")||J("Android"))&&!(yb()||J("iPad")||J("iPod"));var Rb={},Sb=null;var M=window;function Tb(a,b){this.width=a;this.height=b}
p=Tb.prototype;p.clone=function(){return new Tb(this.width,this.height)};
p.aspectRatio=function(){return this.width/this.height};
p.isEmpty=function(){return!(this.width*this.height)};
p.ceil=function(){this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};
p.floor=function(){this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
p.round=function(){this.width=Math.round(this.width);this.height=Math.round(this.height);return this};function Ub(){var a=document;var b="IFRAME";"application/xhtml+xml"===a.contentType&&(b=b.toLowerCase());return a.createElement(b)}
function Vb(a,b){for(var c=0;a;){if(b(a))return a;a=a.parentNode;c++}return null}
;function Wb(a){var b=Xb;if(b)for(var c in b)Object.prototype.hasOwnProperty.call(b,c)&&a.call(void 0,b[c],c,b)}
function Yb(){var a=[];Wb(function(b){a.push(b)});
return a}
var Xb={Da:"allow-forms",Ea:"allow-modals",Fa:"allow-orientation-lock",Ga:"allow-pointer-lock",Ha:"allow-popups",Ia:"allow-popups-to-escape-sandbox",Ja:"allow-presentation",Ka:"allow-same-origin",La:"allow-scripts",Ma:"allow-top-navigation",Na:"allow-top-navigation-by-user-activation"},Zb=Oa(function(){return Yb()});
function $b(){var a=Ub(),b={};H(Zb(),function(c){a.sandbox&&a.sandbox.supports&&a.sandbox.supports(c)&&(b[c]=!0)});
return b}
;var ac=(new Date).getTime();function bc(a){if(!a)return"";a=a.split("#")[0].split("?")[0];a=a.toLowerCase();0==a.indexOf("//")&&(a=window.location.protocol+a);/^[\w\-]*:\/\//.test(a)||(a=window.location.href);var b=a.substring(a.indexOf("://")+3),c=b.indexOf("/");-1!=c&&(b=b.substring(0,c));c=a.substring(0,a.indexOf("://"));if(!c)throw Error("URI is missing protocol: "+a);if("http"!==c&&"https"!==c&&"chrome-extension"!==c&&"moz-extension"!==c&&"file"!==c&&"android-app"!==c&&"chrome-search"!==c&&"chrome-untrusted"!==c&&"chrome"!==
c&&"app"!==c&&"devtools"!==c)throw Error("Invalid URI scheme in origin: "+c);a="";var d=b.indexOf(":");if(-1!=d){var e=b.substring(d+1);b=b.substring(0,d);if("http"===c&&"80"!==e||"https"===c&&"443"!==e)a=":"+e}return c+"://"+b+a}
;function cc(){function a(){e[0]=1732584193;e[1]=4023233417;e[2]=2562383102;e[3]=271733878;e[4]=3285377520;m=l=0}
function b(n){for(var r=g,q=0;64>q;q+=4)r[q/4]=n[q]<<24|n[q+1]<<16|n[q+2]<<8|n[q+3];for(q=16;80>q;q++)n=r[q-3]^r[q-8]^r[q-14]^r[q-16],r[q]=(n<<1|n>>>31)&4294967295;n=e[0];var v=e[1],w=e[2],y=e[3],Q=e[4];for(q=0;80>q;q++){if(40>q)if(20>q){var K=y^v&(w^y);var C=1518500249}else K=v^w^y,C=1859775393;else 60>q?(K=v&w|y&(v|w),C=2400959708):(K=v^w^y,C=3395469782);K=((n<<5|n>>>27)&4294967295)+K+Q+C+r[q]&4294967295;Q=y;y=w;w=(v<<30|v>>>2)&4294967295;v=n;n=K}e[0]=e[0]+n&4294967295;e[1]=e[1]+v&4294967295;e[2]=
e[2]+w&4294967295;e[3]=e[3]+y&4294967295;e[4]=e[4]+Q&4294967295}
function c(n,r){if("string"===typeof n){n=unescape(encodeURIComponent(n));for(var q=[],v=0,w=n.length;v<w;++v)q.push(n.charCodeAt(v));n=q}r||(r=n.length);q=0;if(0==l)for(;q+64<r;)b(n.slice(q,q+64)),q+=64,m+=64;for(;q<r;)if(f[l++]=n[q++],m++,64==l)for(l=0,b(f);q+64<r;)b(n.slice(q,q+64)),q+=64,m+=64}
function d(){var n=[],r=8*m;56>l?c(h,56-l):c(h,64-(l-56));for(var q=63;56<=q;q--)f[q]=r&255,r>>>=8;b(f);for(q=r=0;5>q;q++)for(var v=24;0<=v;v-=8)n[r++]=e[q]>>v&255;return n}
for(var e=[],f=[],g=[],h=[128],k=1;64>k;++k)h[k]=0;var l,m;a();return{reset:a,update:c,digest:d,qa:function(){for(var n=d(),r="",q=0;q<n.length;q++)r+="0123456789ABCDEF".charAt(Math.floor(n[q]/16))+"0123456789ABCDEF".charAt(n[q]%16);return r}}}
;function dc(a,b,c){var d=String(B.location.href);return d&&a&&b?[b,ec(bc(d),a,c||null)].join(" "):null}
function ec(a,b,c){var d=[],e=[];if(1==(Array.isArray(c)?2:1))return e=[b,a],H(d,function(h){e.push(h)}),fc(e.join(" "));
var f=[],g=[];H(c,function(h){g.push(h.key);f.push(h.value)});
c=Math.floor((new Date).getTime()/1E3);e=0==f.length?[c,b,a]:[f.join(":"),c,b,a];H(d,function(h){e.push(h)});
a=fc(e.join(" "));a=[c,a];0==g.length||a.push(g.join(""));return a.join("_")}
function fc(a){var b=cc();b.update(a);return b.qa().toLowerCase()}
;var gc={};function hc(a){this.h=a||{cookie:""}}
p=hc.prototype;p.isEnabled=function(){if(!B.navigator.cookieEnabled)return!1;if(!this.isEmpty())return!0;this.set("TESTCOOKIESENABLED","1",{aa:60});if("1"!==this.get("TESTCOOKIESENABLED"))return!1;this.remove("TESTCOOKIESENABLED");return!0};
p.set=function(a,b,c){var d=!1;if("object"===typeof c){var e=c.Va;d=c.secure||!1;var f=c.domain||void 0;var g=c.path||void 0;var h=c.aa}if(/[;=\s]/.test(a))throw Error('Invalid cookie name "'+a+'"');if(/[;\r\n]/.test(b))throw Error('Invalid cookie value "'+b+'"');void 0===h&&(h=-1);this.h.cookie=a+"="+b+(f?";domain="+f:"")+(g?";path="+g:"")+(0>h?"":0==h?";expires="+(new Date(1970,1,1)).toUTCString():";expires="+(new Date(Date.now()+1E3*h)).toUTCString())+(d?";secure":"")+(null!=e?";samesite="+e:"")};
p.get=function(a,b){for(var c=a+"=",d=(this.h.cookie||"").split(";"),e=0,f;e<d.length;e++){f=db(d[e]);if(0==f.lastIndexOf(c,0))return f.substr(c.length);if(f==a)return""}return b};
p.remove=function(a,b,c){var d=void 0!==this.get(a);this.set(a,"",{aa:0,path:b,domain:c});return d};
p.isEmpty=function(){return!this.h.cookie};
p.clear=function(){for(var a=(this.h.cookie||"").split(";"),b=[],c=[],d,e,f=0;f<a.length;f++)e=db(a[f]),d=e.indexOf("="),-1==d?(b.push(""),c.push(e)):(b.push(e.substring(0,d)),c.push(e.substring(d+1)));for(a=b.length-1;0<=a;a--)this.remove(b[a])};
var ic=new hc("undefined"==typeof document?null:document);function jc(a){return!!gc.FPA_SAMESITE_PHASE2_MOD||!(void 0===a||!a)}
function kc(a,b,c,d){(a=B[a])||(a=(new hc(document)).get(b));return a?dc(a,c,d):null}
function lc(a){var b=void 0===b?!1:b;var c=bc(String(B.location.href)),d=[];var e=b;e=void 0===e?!1:e;var f=B.__SAPISID||B.__APISID||B.__3PSAPISID||B.__OVERRIDE_SID;jc(e)&&(f=f||B.__1PSAPISID);if(f)e=!0;else{var g=new hc(document);f=g.get("SAPISID")||g.get("APISID")||g.get("__Secure-3PAPISID")||g.get("SID");jc(e)&&(f=f||g.get("__Secure-1PAPISID"));e=!!f}e&&(e=(c=0==c.indexOf("https:")||0==c.indexOf("chrome-extension:")||0==c.indexOf("moz-extension:"))?B.__SAPISID:B.__APISID,e||(e=new hc(document),
e=e.get(c?"SAPISID":"APISID")||e.get("__Secure-3PAPISID")),(e=e?dc(e,c?"SAPISIDHASH":"APISIDHASH",a):null)&&d.push(e),c&&jc(b)&&((b=kc("__1PSAPISID","__Secure-1PAPISID","SAPISID1PHASH",a))&&d.push(b),(a=kc("__3PSAPISID","__Secure-3PAPISID","SAPISID3PHASH",a))&&d.push(a)));return 0==d.length?null:d.join(" ")}
;function mc(){this.h=[];this.i=-1}
mc.prototype.set=function(a,b){b=void 0===b?!0:b;0<=a&&52>a&&0===a%1&&this.h[a]!=b&&(this.h[a]=b,this.i=-1)};
mc.prototype.get=function(a){return!!this.h[a]};
function nc(a){-1==a.i&&(a.i=Qa(a.h,function(b,c,d){return c?b+Math.pow(2,d):b},0));
return a.i}
;function oc(a,b){this.j=a;this.l=b;this.i=0;this.h=null}
oc.prototype.get=function(){if(0<this.i){this.i--;var a=this.h;this.h=a.next;a.next=null}else a=this.j();return a};
function pc(a,b){a.l(b);100>a.i&&(a.i++,b.next=a.h,a.h=b)}
;var qc;function rc(){var a=B.MessageChannel;"undefined"===typeof a&&"undefined"!==typeof window&&window.postMessage&&window.addEventListener&&!J("Presto")&&(a=function(){var e=Ub();e.style.display="none";document.documentElement.appendChild(e);var f=e.contentWindow;e=f.document;e.open();e.close();var g="callImmediate"+Math.random(),h="file:"==f.location.protocol?"*":f.location.protocol+"//"+f.location.host;e=Ka(function(k){if(("*"==h||k.origin==h)&&k.data==g)this.port1.onmessage()},this);
f.addEventListener("message",e,!1);this.port1={};this.port2={postMessage:function(){f.postMessage(g,h)}}});
if("undefined"!==typeof a&&!J("Trident")&&!J("MSIE")){var b=new a,c={},d=c;b.port1.onmessage=function(){if(void 0!==c.next){c=c.next;var e=c.da;c.da=null;e()}};
return function(e){d.next={da:e};d=d.next;b.port2.postMessage(0)}}return function(e){B.setTimeout(e,0)}}
;function sc(a){B.setTimeout(function(){throw a;},0)}
;function tc(){this.i=this.h=null}
tc.prototype.add=function(a,b){var c=uc.get();c.set(a,b);this.i?this.i.next=c:this.h=c;this.i=c};
tc.prototype.remove=function(){var a=null;this.h&&(a=this.h,this.h=this.h.next,this.h||(this.i=null),a.next=null);return a};
var uc=new oc(function(){return new vc},function(a){return a.reset()});
function vc(){this.next=this.scope=this.h=null}
vc.prototype.set=function(a,b){this.h=a;this.scope=b;this.next=null};
vc.prototype.reset=function(){this.next=this.scope=this.h=null};function wc(a,b){xc||yc();zc||(xc(),zc=!0);Ac.add(a,b)}
var xc;function yc(){if(B.Promise&&B.Promise.resolve){var a=B.Promise.resolve(void 0);xc=function(){a.then(Bc)}}else xc=function(){var b=Bc;
"function"!==typeof B.setImmediate||B.Window&&B.Window.prototype&&!J("Edge")&&B.Window.prototype.setImmediate==B.setImmediate?(qc||(qc=rc()),qc(b)):B.setImmediate(b)}}
var zc=!1,Ac=new tc;function Bc(){for(var a;a=Ac.remove();){try{a.h.call(a.scope)}catch(b){sc(b)}pc(uc,a)}zc=!1}
;function Cc(){this.i=-1}
;function Dc(){this.i=64;this.h=[];this.s=[];this.o=[];this.l=[];this.l[0]=128;for(var a=1;a<this.i;++a)this.l[a]=0;this.m=this.j=0;this.reset()}
G(Dc,Cc);Dc.prototype.reset=function(){this.h[0]=1732584193;this.h[1]=4023233417;this.h[2]=2562383102;this.h[3]=271733878;this.h[4]=3285377520;this.m=this.j=0};
function Ec(a,b,c){c||(c=0);var d=a.o;if("string"===typeof b)for(var e=0;16>e;e++)d[e]=b.charCodeAt(c)<<24|b.charCodeAt(c+1)<<16|b.charCodeAt(c+2)<<8|b.charCodeAt(c+3),c+=4;else for(e=0;16>e;e++)d[e]=b[c]<<24|b[c+1]<<16|b[c+2]<<8|b[c+3],c+=4;for(e=16;80>e;e++){var f=d[e-3]^d[e-8]^d[e-14]^d[e-16];d[e]=(f<<1|f>>>31)&4294967295}b=a.h[0];c=a.h[1];var g=a.h[2],h=a.h[3],k=a.h[4];for(e=0;80>e;e++){if(40>e)if(20>e){f=h^c&(g^h);var l=1518500249}else f=c^g^h,l=1859775393;else 60>e?(f=c&g|h&(c|g),l=2400959708):
(f=c^g^h,l=3395469782);f=(b<<5|b>>>27)+f+k+l+d[e]&4294967295;k=h;h=g;g=(c<<30|c>>>2)&4294967295;c=b;b=f}a.h[0]=a.h[0]+b&4294967295;a.h[1]=a.h[1]+c&4294967295;a.h[2]=a.h[2]+g&4294967295;a.h[3]=a.h[3]+h&4294967295;a.h[4]=a.h[4]+k&4294967295}
Dc.prototype.update=function(a,b){if(null!=a){void 0===b&&(b=a.length);for(var c=b-this.i,d=0,e=this.s,f=this.j;d<b;){if(0==f)for(;d<=c;)Ec(this,a,d),d+=this.i;if("string"===typeof a)for(;d<b;){if(e[f]=a.charCodeAt(d),++f,++d,f==this.i){Ec(this,e);f=0;break}}else for(;d<b;)if(e[f]=a[d],++f,++d,f==this.i){Ec(this,e);f=0;break}}this.j=f;this.m+=b}};
Dc.prototype.digest=function(){var a=[],b=8*this.m;56>this.j?this.update(this.l,56-this.j):this.update(this.l,this.i-(this.j-56));for(var c=this.i-1;56<=c;c--)this.s[c]=b&255,b/=256;Ec(this,this.s);for(c=b=0;5>c;c++)for(var d=24;0<=d;d-=8)a[b]=this.h[c]>>d&255,++b;return a};function Fc(a){var b=D("window.location.href");null==a&&(a='Unknown Error of type "null/undefined"');if("string"===typeof a)return{message:a,name:"Unknown error",lineNumber:"Not available",fileName:b,stack:"Not available"};var c=!1;try{var d=a.lineNumber||a.line||"Not available"}catch(g){d="Not available",c=!0}try{var e=a.fileName||a.filename||a.sourceURL||B.$googDebugFname||b}catch(g){e="Not available",c=!0}b=Gc(a);if(!(!c&&a.lineNumber&&a.fileName&&a.stack&&a.message&&a.name)){c=a.message;if(null==
c){if(a.constructor&&a.constructor instanceof Function){if(a.constructor.name)c=a.constructor.name;else if(c=a.constructor,Hc[c])c=Hc[c];else{c=String(c);if(!Hc[c]){var f=/function\s+([^\(]+)/m.exec(c);Hc[c]=f?f[1]:"[Anonymous]"}c=Hc[c]}c='Unknown Error of type "'+c+'"'}else c="Unknown Error of unknown type";"function"===typeof a.toString&&Object.prototype.toString!==a.toString&&(c+=": "+a.toString())}return{message:c,name:a.name||"UnknownError",lineNumber:d,fileName:e,stack:b||"Not available"}}a.stack=
b;return{message:a.message,name:a.name,lineNumber:a.lineNumber,fileName:a.fileName,stack:a.stack}}
function Gc(a,b){b||(b={});b[Ic(a)]=!0;var c=a.stack||"";(a=a.pa)&&!b[Ic(a)]&&(c+="\nCaused by: ",a.stack&&0==a.stack.indexOf(a.toString())||(c+="string"===typeof a?a:a.message+"\n"),c+=Gc(a,b));return c}
function Ic(a){var b="";"function"===typeof a.toString&&(b=""+a);return b+a.stack}
var Hc={};function Jc(){this.m=this.m;this.s=this.s}
Jc.prototype.m=!1;Jc.prototype.dispose=function(){this.m||(this.m=!0,this.O())};
Jc.prototype.O=function(){if(this.s)for(;this.s.length;)this.s.shift()()};var Kc="StopIteration"in B?B.StopIteration:{message:"StopIteration",stack:""};function Lc(){}
Lc.prototype.next=function(){throw Kc;};
Lc.prototype.G=function(){return this};
function Mc(a){if(a instanceof Lc)return a;if("function"==typeof a.G)return a.G(!1);if(Ea(a)){var b=0,c=new Lc;c.next=function(){for(;;){if(b>=a.length)throw Kc;if(b in a)return a[b++];b++}};
return c}throw Error("Not implemented");}
function Nc(a,b){if(Ea(a))try{H(a,b,void 0)}catch(c){if(c!==Kc)throw c;}else{a=Mc(a);try{for(;;)b.call(void 0,a.next(),void 0,a)}catch(c){if(c!==Kc)throw c;}}}
function Oc(a){if(Ea(a))return Ua(a);a=Mc(a);var b=[];Nc(a,function(c){b.push(c)});
return b}
;function Pc(a,b){this.i={};this.h=[];this.l=this.j=0;var c=arguments.length;if(1<c){if(c%2)throw Error("Uneven number of arguments");for(var d=0;d<c;d+=2)this.set(arguments[d],arguments[d+1])}else if(a)if(a instanceof Pc)for(c=Qc(a),d=0;d<c.length;d++)this.set(c[d],a.get(c[d]));else for(d in a)this.set(d,a[d])}
function Qc(a){Rc(a);return a.h.concat()}
p=Pc.prototype;p.equals=function(a,b){if(this===a)return!0;if(this.j!=a.j)return!1;b=b||Sc;Rc(this);for(var c,d=0;c=this.h[d];d++)if(!b(this.get(c),a.get(c)))return!1;return!0};
function Sc(a,b){return a===b}
p.isEmpty=function(){return 0==this.j};
p.clear=function(){this.i={};this.l=this.j=this.h.length=0};
p.remove=function(a){return Object.prototype.hasOwnProperty.call(this.i,a)?(delete this.i[a],this.j--,this.l++,this.h.length>2*this.j&&Rc(this),!0):!1};
function Rc(a){if(a.j!=a.h.length){for(var b=0,c=0;b<a.h.length;){var d=a.h[b];Object.prototype.hasOwnProperty.call(a.i,d)&&(a.h[c++]=d);b++}a.h.length=c}if(a.j!=a.h.length){var e={};for(c=b=0;b<a.h.length;)d=a.h[b],Object.prototype.hasOwnProperty.call(e,d)||(a.h[c++]=d,e[d]=1),b++;a.h.length=c}}
p.get=function(a,b){return Object.prototype.hasOwnProperty.call(this.i,a)?this.i[a]:b};
p.set=function(a,b){Object.prototype.hasOwnProperty.call(this.i,a)||(this.j++,this.h.push(a),this.l++);this.i[a]=b};
p.forEach=function(a,b){for(var c=Qc(this),d=0;d<c.length;d++){var e=c[d],f=this.get(e);a.call(b,f,e,this)}};
p.clone=function(){return new Pc(this)};
p.G=function(a){Rc(this);var b=0,c=this.l,d=this,e=new Lc;e.next=function(){if(c!=d.l)throw Error("The map has changed since the iterator was created");if(b>=d.h.length)throw Kc;var f=d.h[b++];return a?f:d.i[f]};
return e};var Tc=function(){if(!B.addEventListener||!Object.defineProperty)return!1;var a=!1,b=Object.defineProperty({},"passive",{get:function(){a=!0}});
try{B.addEventListener("test",Da,b),B.removeEventListener("test",Da,b)}catch(c){}return a}();function Uc(a,b){this.type=a;this.h=this.target=b;this.defaultPrevented=this.j=!1}
Uc.prototype.stopPropagation=function(){this.j=!0};
Uc.prototype.preventDefault=function(){this.defaultPrevented=!0};function Vc(a,b){Uc.call(this,a?a.type:"");this.relatedTarget=this.h=this.target=null;this.button=this.screenY=this.screenX=this.clientY=this.clientX=0;this.key="";this.charCode=this.keyCode=0;this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1;this.state=null;this.pointerId=0;this.pointerType="";this.i=null;a&&this.init(a,b)}
G(Vc,Uc);var Wc={2:"touch",3:"pen",4:"mouse"};
Vc.prototype.init=function(a,b){var c=this.type=a.type,d=a.changedTouches&&a.changedTouches.length?a.changedTouches[0]:null;this.target=a.target||a.srcElement;this.h=b;if(b=a.relatedTarget){if(Db){a:{try{zb(b.nodeName);var e=!0;break a}catch(f){}e=!1}e||(b=null)}}else"mouseover"==c?b=a.fromElement:"mouseout"==c&&(b=a.toElement);this.relatedTarget=b;d?(this.clientX=void 0!==d.clientX?d.clientX:d.pageX,this.clientY=void 0!==d.clientY?d.clientY:d.pageY,this.screenX=d.screenX||0,this.screenY=d.screenY||
0):(this.clientX=void 0!==a.clientX?a.clientX:a.pageX,this.clientY=void 0!==a.clientY?a.clientY:a.pageY,this.screenX=a.screenX||0,this.screenY=a.screenY||0);this.button=a.button;this.keyCode=a.keyCode||0;this.key=a.key||"";this.charCode=a.charCode||("keypress"==c?a.keyCode:0);this.ctrlKey=a.ctrlKey;this.altKey=a.altKey;this.shiftKey=a.shiftKey;this.metaKey=a.metaKey;this.pointerId=a.pointerId||0;this.pointerType="string"===typeof a.pointerType?a.pointerType:Wc[a.pointerType]||"";this.state=a.state;
this.i=a;a.defaultPrevented&&Vc.D.preventDefault.call(this)};
Vc.prototype.stopPropagation=function(){Vc.D.stopPropagation.call(this);this.i.stopPropagation?this.i.stopPropagation():this.i.cancelBubble=!0};
Vc.prototype.preventDefault=function(){Vc.D.preventDefault.call(this);var a=this.i;a.preventDefault?a.preventDefault():a.returnValue=!1};var Xc="closure_listenable_"+(1E6*Math.random()|0);var Yc=0;function Zc(a,b,c,d,e){this.listener=a;this.h=null;this.src=b;this.type=c;this.capture=!!d;this.W=e;this.key=++Yc;this.P=this.T=!1}
function $c(a){a.P=!0;a.listener=null;a.h=null;a.src=null;a.W=null}
;function ad(a){this.src=a;this.listeners={};this.h=0}
ad.prototype.add=function(a,b,c,d,e){var f=a.toString();a=this.listeners[f];a||(a=this.listeners[f]=[],this.h++);var g=bd(a,b,d,e);-1<g?(b=a[g],c||(b.T=!1)):(b=new Zc(b,this.src,f,!!d,e),b.T=c,a.push(b));return b};
ad.prototype.remove=function(a,b,c,d){a=a.toString();if(!(a in this.listeners))return!1;var e=this.listeners[a];b=bd(e,b,c,d);return-1<b?($c(e[b]),Array.prototype.splice.call(e,b,1),0==e.length&&(delete this.listeners[a],this.h--),!0):!1};
function cd(a,b){var c=b.type;c in a.listeners&&Sa(a.listeners[c],b)&&($c(b),0==a.listeners[c].length&&(delete a.listeners[c],a.h--))}
function bd(a,b,c,d){for(var e=0;e<a.length;++e){var f=a[e];if(!f.P&&f.listener==b&&f.capture==!!c&&f.W==d)return e}return-1}
;var dd="closure_lm_"+(1E6*Math.random()|0),ed={},fd=0;function gd(a,b,c,d,e){if(d&&d.once)hd(a,b,c,d,e);else if(Array.isArray(b))for(var f=0;f<b.length;f++)gd(a,b[f],c,d,e);else c=id(c),a&&a[Xc]?jd(a,b,c,E(d)?!!d.capture:!!d,e):kd(a,b,c,!1,d,e)}
function kd(a,b,c,d,e,f){if(!b)throw Error("Invalid event type");var g=E(e)?!!e.capture:!!e,h=ld(a);h||(a[dd]=h=new ad(a));c=h.add(b,c,d,g,f);if(!c.h){d=md();c.h=d;d.src=a;d.listener=c;if(a.addEventListener)Tc||(e=g),void 0===e&&(e=!1),a.addEventListener(b.toString(),d,e);else if(a.attachEvent)a.attachEvent(nd(b.toString()),d);else if(a.addListener&&a.removeListener)a.addListener(d);else throw Error("addEventListener and attachEvent are unavailable.");fd++}}
function md(){function a(c){return b.call(a.src,a.listener,c)}
var b=od;return a}
function hd(a,b,c,d,e){if(Array.isArray(b))for(var f=0;f<b.length;f++)hd(a,b[f],c,d,e);else c=id(c),a&&a[Xc]?a.i.add(String(b),c,!0,E(d)?!!d.capture:!!d,e):kd(a,b,c,!0,d,e)}
function pd(a,b,c,d,e){if(Array.isArray(b))for(var f=0;f<b.length;f++)pd(a,b[f],c,d,e);else(d=E(d)?!!d.capture:!!d,c=id(c),a&&a[Xc])?a.i.remove(String(b),c,d,e):a&&(a=ld(a))&&(b=a.listeners[b.toString()],a=-1,b&&(a=bd(b,c,d,e)),(c=-1<a?b[a]:null)&&qd(c))}
function qd(a){if("number"!==typeof a&&a&&!a.P){var b=a.src;if(b&&b[Xc])cd(b.i,a);else{var c=a.type,d=a.h;b.removeEventListener?b.removeEventListener(c,d,a.capture):b.detachEvent?b.detachEvent(nd(c),d):b.addListener&&b.removeListener&&b.removeListener(d);fd--;(c=ld(b))?(cd(c,a),0==c.h&&(c.src=null,b[dd]=null)):$c(a)}}}
function nd(a){return a in ed?ed[a]:ed[a]="on"+a}
function od(a,b){if(a.P)a=!0;else{b=new Vc(b,this);var c=a.listener,d=a.W||a.src;a.T&&qd(a);a=c.call(d,b)}return a}
function ld(a){a=a[dd];return a instanceof ad?a:null}
var rd="__closure_events_fn_"+(1E9*Math.random()>>>0);function id(a){if("function"===typeof a)return a;a[rd]||(a[rd]=function(b){return a.handleEvent(b)});
return a[rd]}
;function N(){Jc.call(this);this.i=new ad(this);this.Z=this;this.J=null}
G(N,Jc);N.prototype[Xc]=!0;N.prototype.addEventListener=function(a,b,c,d){gd(this,a,b,c,d)};
N.prototype.removeEventListener=function(a,b,c,d){pd(this,a,b,c,d)};
function O(a,b){var c=a.J;if(c){var d=[];for(var e=1;c;c=c.J)d.push(c),++e}a=a.Z;c=b.type||b;"string"===typeof b?b=new Uc(b,a):b instanceof Uc?b.target=b.target||a:(e=b,b=new Uc(c,a),bb(b,e));e=!0;if(d)for(var f=d.length-1;!b.j&&0<=f;f--){var g=b.h=d[f];e=sd(g,c,!0,b)&&e}b.j||(g=b.h=a,e=sd(g,c,!0,b)&&e,b.j||(e=sd(g,c,!1,b)&&e));if(d)for(f=0;!b.j&&f<d.length;f++)g=b.h=d[f],e=sd(g,c,!1,b)&&e}
N.prototype.O=function(){N.D.O.call(this);if(this.i){var a=this.i,b=0,c;for(c in a.listeners){for(var d=a.listeners[c],e=0;e<d.length;e++)++b,$c(d[e]);delete a.listeners[c];a.h--}}this.J=null};
function jd(a,b,c,d,e){a.i.add(String(b),c,!1,d,e)}
function sd(a,b,c,d){b=a.i.listeners[String(b)];if(!b)return!0;b=b.concat();for(var e=!0,f=0;f<b.length;++f){var g=b[f];if(g&&!g.P&&g.capture==c){var h=g.listener,k=g.W||g.src;g.T&&cd(a.i,g);e=!1!==h.call(k,d)&&e}}return e&&!d.defaultPrevented}
;var td=B.JSON.stringify;function P(a){this.h=0;this.o=void 0;this.l=this.i=this.j=null;this.m=this.s=!1;if(a!=Da)try{var b=this;a.call(void 0,function(c){ud(b,2,c)},function(c){ud(b,3,c)})}catch(c){ud(this,3,c)}}
function vd(){this.next=this.context=this.onRejected=this.i=this.h=null;this.j=!1}
vd.prototype.reset=function(){this.context=this.onRejected=this.i=this.h=null;this.j=!1};
var wd=new oc(function(){return new vd},function(a){a.reset()});
function xd(a,b,c){var d=wd.get();d.i=a;d.onRejected=b;d.context=c;return d}
P.prototype.then=function(a,b,c){return yd(this,"function"===typeof a?a:null,"function"===typeof b?b:null,c)};
P.prototype.$goog_Thenable=!0;P.prototype.cancel=function(a){if(0==this.h){var b=new zd(a);wc(function(){Ad(this,b)},this)}};
function Ad(a,b){if(0==a.h)if(a.j){var c=a.j;if(c.i){for(var d=0,e=null,f=null,g=c.i;g&&(g.j||(d++,g.h==a&&(e=g),!(e&&1<d)));g=g.next)e||(f=g);e&&(0==c.h&&1==d?Ad(c,b):(f?(d=f,d.next==c.l&&(c.l=d),d.next=d.next.next):Bd(c),Cd(c,e,3,b)))}a.j=null}else ud(a,3,b)}
function Dd(a,b){a.i||2!=a.h&&3!=a.h||Ed(a);a.l?a.l.next=b:a.i=b;a.l=b}
function yd(a,b,c,d){var e=xd(null,null,null);e.h=new P(function(f,g){e.i=b?function(h){try{var k=b.call(d,h);f(k)}catch(l){g(l)}}:f;
e.onRejected=c?function(h){try{var k=c.call(d,h);void 0===k&&h instanceof zd?g(h):f(k)}catch(l){g(l)}}:g});
e.h.j=a;Dd(a,e);return e.h}
P.prototype.B=function(a){this.h=0;ud(this,2,a)};
P.prototype.J=function(a){this.h=0;ud(this,3,a)};
function ud(a,b,c){if(0==a.h){a===c&&(b=3,c=new TypeError("Promise cannot resolve to itself"));a.h=1;a:{var d=c,e=a.B,f=a.J;if(d instanceof P){Dd(d,xd(e||Da,f||null,a));var g=!0}else{if(d)try{var h=!!d.$goog_Thenable}catch(l){h=!1}else h=!1;if(h)d.then(e,f,a),g=!0;else{if(E(d))try{var k=d.then;if("function"===typeof k){Fd(d,k,e,f,a);g=!0;break a}}catch(l){f.call(a,l);g=!0;break a}g=!1}}}g||(a.o=c,a.h=b,a.j=null,Ed(a),3!=b||c instanceof zd||Gd(a,c))}}
function Fd(a,b,c,d,e){function f(k){h||(h=!0,d.call(e,k))}
function g(k){h||(h=!0,c.call(e,k))}
var h=!1;try{b.call(a,g,f)}catch(k){f(k)}}
function Ed(a){a.s||(a.s=!0,wc(a.v,a))}
function Bd(a){var b=null;a.i&&(b=a.i,a.i=b.next,b.next=null);a.i||(a.l=null);return b}
P.prototype.v=function(){for(var a;a=Bd(this);)Cd(this,a,this.h,this.o);this.s=!1};
function Cd(a,b,c,d){if(3==c&&b.onRejected&&!b.j)for(;a&&a.m;a=a.j)a.m=!1;if(b.h)b.h.j=null,Hd(b,c,d);else try{b.j?b.i.call(b.context):Hd(b,c,d)}catch(e){Id.call(null,e)}pc(wd,b)}
function Hd(a,b,c){2==b?a.i.call(a.context,c):a.onRejected&&a.onRejected.call(a.context,c)}
function Gd(a,b){a.m=!0;wc(function(){a.m&&Id.call(null,b)})}
var Id=sc;function zd(a){Ma.call(this,a)}
G(zd,Ma);zd.prototype.name="cancel";function R(a){Jc.call(this);this.o=1;this.j=[];this.l=0;this.h=[];this.i={};this.v=!!a}
G(R,Jc);p=R.prototype;p.subscribe=function(a,b,c){var d=this.i[a];d||(d=this.i[a]=[]);var e=this.o;this.h[e]=a;this.h[e+1]=b;this.h[e+2]=c;this.o=e+3;d.push(e);return e};
function Jd(a,b,c){var d=Kd;if(a=d.i[a]){var e=d.h;(a=Ra(a,function(f){return e[f+1]==b&&e[f+2]==c}))&&d.R(a)}}
p.R=function(a){var b=this.h[a];if(b){var c=this.i[b];0!=this.l?(this.j.push(a),this.h[a+1]=Da):(c&&Sa(c,a),delete this.h[a],delete this.h[a+1],delete this.h[a+2])}return!!b};
p.M=function(a,b){var c=this.i[a];if(c){for(var d=Array(arguments.length-1),e=1,f=arguments.length;e<f;e++)d[e-1]=arguments[e];if(this.v)for(e=0;e<c.length;e++){var g=c[e];Ld(this.h[g+1],this.h[g+2],d)}else{this.l++;try{for(e=0,f=c.length;e<f;e++)g=c[e],this.h[g+1].apply(this.h[g+2],d)}finally{if(this.l--,0<this.j.length&&0==this.l)for(;c=this.j.pop();)this.R(c)}}return 0!=e}return!1};
function Ld(a,b,c){wc(function(){a.apply(b,c)})}
p.clear=function(a){if(a){var b=this.i[a];b&&(H(b,this.R,this),delete this.i[a])}else this.h.length=0,this.i={}};
p.O=function(){R.D.O.call(this);this.clear();this.j.length=0};function Md(a){this.h=a}
Md.prototype.set=function(a,b){void 0===b?this.h.remove(a):this.h.set(a,td(b))};
Md.prototype.get=function(a){try{var b=this.h.get(a)}catch(c){return}if(null!==b)try{return JSON.parse(b)}catch(c){throw"Storage: Invalid value was encountered";}};
Md.prototype.remove=function(a){this.h.remove(a)};function Nd(a){this.h=a}
G(Nd,Md);function Od(a){this.data=a}
function Pd(a){return void 0===a||a instanceof Od?a:new Od(a)}
Nd.prototype.set=function(a,b){Nd.D.set.call(this,a,Pd(b))};
Nd.prototype.i=function(a){a=Nd.D.get.call(this,a);if(void 0===a||a instanceof Object)return a;throw"Storage: Invalid value was encountered";};
Nd.prototype.get=function(a){if(a=this.i(a)){if(a=a.data,void 0===a)throw"Storage: Invalid value was encountered";}else a=void 0;return a};function Qd(a){this.h=a}
G(Qd,Nd);Qd.prototype.set=function(a,b,c){if(b=Pd(b)){if(c){if(c<Date.now()){Qd.prototype.remove.call(this,a);return}b.expiration=c}b.creation=Date.now()}Qd.D.set.call(this,a,b)};
Qd.prototype.i=function(a){var b=Qd.D.i.call(this,a);if(b){var c=b.creation,d=b.expiration;if(d&&d<Date.now()||c&&c>Date.now())Qd.prototype.remove.call(this,a);else return b}};function Rd(){}
;function Sd(){}
G(Sd,Rd);Sd.prototype.clear=function(){var a=Oc(this.G(!0)),b=this;H(a,function(c){b.remove(c)})};function Td(a){this.h=a}
G(Td,Sd);p=Td.prototype;p.isAvailable=function(){if(!this.h)return!1;try{return this.h.setItem("__sak","1"),this.h.removeItem("__sak"),!0}catch(a){return!1}};
p.set=function(a,b){try{this.h.setItem(a,b)}catch(c){if(0==this.h.length)throw"Storage mechanism: Storage disabled";throw"Storage mechanism: Quota exceeded";}};
p.get=function(a){a=this.h.getItem(a);if("string"!==typeof a&&null!==a)throw"Storage mechanism: Invalid value was encountered";return a};
p.remove=function(a){this.h.removeItem(a)};
p.G=function(a){var b=0,c=this.h,d=new Lc;d.next=function(){if(b>=c.length)throw Kc;var e=c.key(b++);if(a)return e;e=c.getItem(e);if("string"!==typeof e)throw"Storage mechanism: Invalid value was encountered";return e};
return d};
p.clear=function(){this.h.clear()};
p.key=function(a){return this.h.key(a)};function Ud(){var a=null;try{a=window.localStorage||null}catch(b){}this.h=a}
G(Ud,Td);function Vd(a,b){this.i=a;this.h=null;if(Bb&&!(9<=Number(Nb))){Wd||(Wd=new Pc);this.h=Wd.get(a);this.h||(b?this.h=document.getElementById(b):(this.h=document.createElement("userdata"),this.h.addBehavior("#default#userData"),document.body.appendChild(this.h)),Wd.set(a,this.h));try{this.h.load(this.i)}catch(c){this.h=null}}}
G(Vd,Sd);var Xd={".":".2E","!":".21","~":".7E","*":".2A","'":".27","(":".28",")":".29","%":"."},Wd=null;function Yd(a){return"_"+encodeURIComponent(a).replace(/[.!~*'()%]/g,function(b){return Xd[b]})}
p=Vd.prototype;p.isAvailable=function(){return!!this.h};
p.set=function(a,b){this.h.setAttribute(Yd(a),b);Zd(this)};
p.get=function(a){a=this.h.getAttribute(Yd(a));if("string"!==typeof a&&null!==a)throw"Storage mechanism: Invalid value was encountered";return a};
p.remove=function(a){this.h.removeAttribute(Yd(a));Zd(this)};
p.G=function(a){var b=0,c=this.h.XMLDocument.documentElement.attributes,d=new Lc;d.next=function(){if(b>=c.length)throw Kc;var e=c[b++];if(a)return decodeURIComponent(e.nodeName.replace(/\./g,"%")).substr(1);e=e.nodeValue;if("string"!==typeof e)throw"Storage mechanism: Invalid value was encountered";return e};
return d};
p.clear=function(){for(var a=this.h.XMLDocument.documentElement,b=a.attributes.length;0<b;b--)a.removeAttribute(a.attributes[b-1].nodeName);Zd(this)};
function Zd(a){try{a.h.save(a.i)}catch(b){throw"Storage mechanism: Quota exceeded";}}
;function $d(a,b){this.i=a;this.h=b+"::"}
G($d,Sd);$d.prototype.set=function(a,b){this.i.set(this.h+a,b)};
$d.prototype.get=function(a){return this.i.get(this.h+a)};
$d.prototype.remove=function(a){this.i.remove(this.h+a)};
$d.prototype.G=function(a){var b=this.i.G(!0),c=this,d=new Lc;d.next=function(){for(var e=b.next();e.substr(0,c.h.length)!=c.h;)e=b.next();return a?e.substr(c.h.length):c.i.get(e)};
return d};var ae=window.yt&&window.yt.config_||window.ytcfg&&window.ytcfg.data_||{};F("yt.config_",ae);function be(a){var b=arguments;1<b.length?ae[b[0]]=b[1]:1===b.length&&Object.assign(ae,b[0])}
function S(a,b){return a in ae?ae[a]:b}
;var ce=[];function de(a){ce.forEach(function(b){return b(a)})}
function ee(a){return a&&window.yterr?function(){try{return a.apply(this,arguments)}catch(b){fe(b)}}:a}
function fe(a){var b=D("yt.logging.errors.log");b?b(a,"ERROR",void 0,void 0,void 0):(b=S("ERRORS",[]),b.push([a,"ERROR",void 0,void 0,void 0]),be("ERRORS",b));de(a)}
function ge(a){var b=D("yt.logging.errors.log");b?b(a,"WARNING",void 0,void 0,void 0):(b=S("ERRORS",[]),b.push([a,"WARNING",void 0,void 0,void 0]),be("ERRORS",b))}
;var he=0;F("ytDomDomGetNextId",D("ytDomDomGetNextId")||function(){return++he});var ie={stopImmediatePropagation:1,stopPropagation:1,preventMouseEvent:1,preventManipulation:1,preventDefault:1,layerX:1,layerY:1,screenX:1,screenY:1,scale:1,rotation:1,webkitMovementX:1,webkitMovementY:1};
function je(a){this.type="";this.state=this.source=this.data=this.currentTarget=this.relatedTarget=this.target=null;this.charCode=this.keyCode=0;this.metaKey=this.shiftKey=this.ctrlKey=this.altKey=!1;this.clientY=this.clientX=0;this.changedTouches=this.touches=null;try{if(a=a||window.event){this.event=a;for(var b in a)b in ie||(this[b]=a[b]);var c=a.target||a.srcElement;c&&3==c.nodeType&&(c=c.parentNode);this.target=c;var d=a.relatedTarget;if(d)try{d=d.nodeName?d:null}catch(e){d=null}else"mouseover"==
this.type?d=a.fromElement:"mouseout"==this.type&&(d=a.toElement);this.relatedTarget=d;this.clientX=void 0!=a.clientX?a.clientX:a.pageX;this.clientY=void 0!=a.clientY?a.clientY:a.pageY;this.keyCode=a.keyCode?a.keyCode:a.which;this.charCode=a.charCode||("keypress"==this.type?this.keyCode:0);this.altKey=a.altKey;this.ctrlKey=a.ctrlKey;this.shiftKey=a.shiftKey;this.metaKey=a.metaKey}}catch(e){}}
je.prototype.preventDefault=function(){this.event&&(this.event.returnValue=!1,this.event.preventDefault&&this.event.preventDefault())};
je.prototype.stopPropagation=function(){this.event&&(this.event.cancelBubble=!0,this.event.stopPropagation&&this.event.stopPropagation())};
je.prototype.stopImmediatePropagation=function(){this.event&&(this.event.cancelBubble=!0,this.event.stopImmediatePropagation&&this.event.stopImmediatePropagation())};var Ya=B.ytEventsEventsListeners||{};F("ytEventsEventsListeners",Ya);var ke=B.ytEventsEventsCounter||{count:0};F("ytEventsEventsCounter",ke);
function le(a,b,c,d){d=void 0===d?{}:d;a.addEventListener&&("mouseenter"!=b||"onmouseenter"in document?"mouseleave"!=b||"onmouseenter"in document?"mousewheel"==b&&"MozBoxSizing"in document.documentElement.style&&(b="MozMousePixelScroll"):b="mouseout":b="mouseover");return Xa(function(e){var f="boolean"===typeof e[4]&&e[4]==!!d,g=E(e[4])&&E(d)&&Za(e[4],d);return!!e.length&&e[0]==a&&e[1]==b&&e[2]==c&&(f||g)})}
function me(a){a&&("string"==typeof a&&(a=[a]),H(a,function(b){if(b in Ya){var c=Ya[b],d=c[0],e=c[1],f=c[3];c=c[4];d.removeEventListener?ne()||"boolean"===typeof c?d.removeEventListener(e,f,c):d.removeEventListener(e,f,!!c.capture):d.detachEvent&&d.detachEvent("on"+e,f);delete Ya[b]}}))}
var ne=Oa(function(){var a=!1;try{var b=Object.defineProperty({},"capture",{get:function(){a=!0}});
window.addEventListener("test",null,b)}catch(c){}return a});
function oe(a,b,c){var d=void 0===d?{}:d;if(a&&(a.addEventListener||a.attachEvent)){var e=le(a,b,c,d);if(!e){e=++ke.count+"";var f=!("mouseenter"!=b&&"mouseleave"!=b||!a.addEventListener||"onmouseenter"in document);var g=f?function(h){h=new je(h);if(!Vb(h.relatedTarget,function(k){return k==a}))return h.currentTarget=a,h.type=b,c.call(a,h)}:function(h){h=new je(h);
h.currentTarget=a;return c.call(a,h)};
g=ee(g);a.addEventListener?("mouseenter"==b&&f?b="mouseover":"mouseleave"==b&&f?b="mouseout":"mousewheel"==b&&"MozBoxSizing"in document.documentElement.style&&(b="MozMousePixelScroll"),ne()||"boolean"===typeof d?a.addEventListener(b,g,d):a.addEventListener(b,g,!!d.capture)):a.attachEvent("on"+b,g);Ya[e]=[a,b,c,g,d]}}}
;function pe(a,b){"function"===typeof a&&(a=ee(a));return window.setTimeout(a,b)}
function qe(a){"function"===typeof a&&(a=ee(a));return window.setInterval(a,250)}
;var re=/^[\w.]*$/,se={q:!0,search_query:!0};function te(a,b){b=a.split(b);for(var c={},d=0,e=b.length;d<e;d++){var f=b[d].split("=");if(1==f.length&&f[0]||2==f.length)try{var g=ue(f[0]||""),h=ue(f[1]||"");g in c?Array.isArray(c[g])?Va(c[g],h):c[g]=[c[g],h]:c[g]=h}catch(n){var k=n,l=f[0],m=String(te);k.args=[{key:l,value:f[1],query:a,method:ve==m?"unchanged":m}];se.hasOwnProperty(l)||ge(k)}}return c}
var ve=String(te);function we(a){var b=[];Wa(a,function(c,d){var e=encodeURIComponent(String(d)),f;Array.isArray(c)?f=c:f=[c];H(f,function(g){""==g?b.push(e):b.push(e+"="+encodeURIComponent(String(g)))})});
return b.join("&")}
function xe(a){"?"==a.charAt(0)&&(a=a.substr(1));return te(a,"&")}
function ye(a,b,c){var d=a.split("#",2);a=d[0];d=1<d.length?"#"+d[1]:"";var e=a.split("?",2);a=e[0];e=xe(e[1]||"");for(var f in b)!c&&null!==e&&f in e||(e[f]=b[f]);b=a;a=vb(e);a?(c=b.indexOf("#"),0>c&&(c=b.length),f=b.indexOf("?"),0>f||f>c?(f=c,e=""):e=b.substring(f+1,c),b=[b.substr(0,f),e,b.substr(c)],c=b[1],b[1]=a?c?c+"&"+a:a:c,a=b[0]+(b[1]?"?"+b[1]:"")+b[2]):a=b;return a+d}
function ze(a){if(!b)var b=window.location.href;var c=a.match(qb)[1]||null,d=sb(a);c&&d?(a=a.match(qb),b=b.match(qb),a=a[3]==b[3]&&a[1]==b[1]&&a[4]==b[4]):a=d?sb(b)==d&&(Number(b.match(qb)[4]||null)||null)==(Number(a.match(qb)[4]||null)||null):!0;return a}
function ue(a){return a&&a.match(re)?a:decodeURIComponent(a.replace(/\+/g," "))}
;function T(a){a=Ae(a);return"string"===typeof a&&"false"===a?!1:!!a}
function Be(a,b){a=Ae(a);return void 0===a&&void 0!==b?b:Number(a||0)}
function Ae(a){var b=S("EXPERIMENTS_FORCED_FLAGS",{});return void 0!==b[a]?b[a]:S("EXPERIMENT_FLAGS",{})[a]}
;function Ce(){}
function De(a,b){return Ee(a,0,b)}
function Fe(a,b){return Ee(a,1,b)}
;function Ge(){Ce.apply(this,arguments)}
ma(Ge,Ce);function Ee(a,b,c){void 0!==c&&Number.isNaN(Number(c))&&(c=void 0);var d=D("yt.scheduler.instance.addJob");return d?d(a,b,c):void 0===c?(a(),NaN):pe(a,c||0)}
function He(a){if(void 0===a||!Number.isNaN(Number(a))){var b=D("yt.scheduler.instance.cancelJob");b?b(a):window.clearTimeout(a)}}
Ge.prototype.start=function(){var a=D("yt.scheduler.instance.start");a&&a()};Ge.h||(Ge.h=new Ge);function Ie(a){var b=Je;a=void 0===a?D("yt.ads.biscotti.lastId_")||"":a;var c=Object,d=c.assign,e={};e.dt=ac;e.flash="0";a:{try{var f=b.h.top.location.href}catch(oa){f=2;break a}f=f?f===b.i.location.href?0:1:2}e=(e.frm=f,e);e.u_tz=-(new Date).getTimezoneOffset();var g=void 0===g?M:g;try{var h=g.history.length}catch(oa){h=0}e.u_his=h;e.u_java=!!M.navigator&&"unknown"!==typeof M.navigator.javaEnabled&&!!M.navigator.javaEnabled&&M.navigator.javaEnabled();M.screen&&(e.u_h=M.screen.height,e.u_w=M.screen.width,
e.u_ah=M.screen.availHeight,e.u_aw=M.screen.availWidth,e.u_cd=M.screen.colorDepth);M.navigator&&M.navigator.plugins&&(e.u_nplug=M.navigator.plugins.length);M.navigator&&M.navigator.mimeTypes&&(e.u_nmime=M.navigator.mimeTypes.length);h=b.h;try{var k=h.screenX;var l=h.screenY}catch(oa){}try{var m=h.outerWidth;var n=h.outerHeight}catch(oa){}try{var r=h.innerWidth;var q=h.innerHeight}catch(oa){}try{var v=h.screenLeft;var w=h.screenTop}catch(oa){}try{r=h.innerWidth,q=h.innerHeight}catch(oa){}try{var y=
h.screen.availWidth;var Q=h.screen.availTop}catch(oa){}k=[v,w,k,l,y,Q,m,n,r,q];l=b.h.top;try{var K=(l||window).document,C="CSS1Compat"==K.compatMode?K.documentElement:K.body;var I=(new Tb(C.clientWidth,C.clientHeight)).round()}catch(oa){I=new Tb(-12245933,-12245933)}K=I;I={};C=new mc;B.SVGElement&&B.document.createElementNS&&C.set(0);l=$b();l["allow-top-navigation-by-user-activation"]&&C.set(1);l["allow-popups-to-escape-sandbox"]&&C.set(2);B.crypto&&B.crypto.subtle&&C.set(3);B.TextDecoder&&B.TextEncoder&&
C.set(4);C=nc(C);I.bc=C;I.bih=K.height;I.biw=K.width;I.brdim=k.join();b=b.i;b=(I.vis={visible:1,hidden:2,prerender:3,preview:4,unloaded:5}[b.visibilityState||b.webkitVisibilityState||b.mozVisibilityState||""]||0,I.wgl=!!M.WebGLRenderingContext,I);c=d.call(c,e,b);c.ca_type="image";a&&(c.bid=a);return c}
var Je=new function(){var a=window.document;this.h=window;this.i=a};
F("yt.ads_.signals_.getAdSignalsString",function(a){return we(Ie(a))});var Ke="XMLHttpRequest"in B?function(){return new XMLHttpRequest}:null;
function Le(){if(!Ke)return null;var a=Ke();return"open"in a?a:null}
;var Me={Authorization:"AUTHORIZATION","X-Goog-Visitor-Id":"SANDBOXED_VISITOR_ID","X-Youtube-Chrome-Connected":"CHROME_CONNECTED_HEADER","X-YouTube-Client-Name":"INNERTUBE_CONTEXT_CLIENT_NAME","X-YouTube-Client-Version":"INNERTUBE_CONTEXT_CLIENT_VERSION","X-YouTube-Delegation-Context":"INNERTUBE_CONTEXT_SERIALIZED_DELEGATION_CONTEXT","X-YouTube-Device":"DEVICE","X-Youtube-Identity-Token":"ID_TOKEN","X-YouTube-Page-CL":"PAGE_CL","X-YouTube-Page-Label":"PAGE_BUILD_LABEL","X-YouTube-Variants-Checksum":"VARIANTS_CHECKSUM"},
Ne="app debugcss debugjs expflag force_ad_params force_ad_encrypted force_viral_ad_response_params forced_experiments innertube_snapshots innertube_goldens internalcountrycode internalipoverride absolute_experiments conditional_experiments sbb sr_bns_address client_dev_root_url".split(" "),Oe=!1;
function Pe(a,b){b=void 0===b?{}:b;var c=ze(a),d=T("web_ajax_ignore_global_headers_if_set"),e;for(e in Me){var f=S(Me[e]);!f||!c&&sb(a)||d&&void 0!==b[e]||(b[e]=f)}if(c||!sb(a))b["X-YouTube-Utc-Offset"]=String(-(new Date).getTimezoneOffset());if(c||!sb(a)){try{var g=(new Intl.DateTimeFormat).resolvedOptions().timeZone}catch(h){}g&&(b["X-YouTube-Time-Zone"]=g)}if(c||!sb(a))b["X-YouTube-Ad-Signals"]=we(Ie(void 0));return b}
function Qe(a){var b=window.location.search,c=sb(a);T("debug_handle_relative_url_for_query_forward_killswitch")||c||!ze(a)||(c=document.location.hostname);var d=rb(a.match(qb)[5]||null);d=(c=c&&(c.endsWith("youtube.com")||c.endsWith("youtube-nocookie.com")))&&d&&d.startsWith("/api/");if(!c||d)return a;var e=xe(b),f={};H(Ne,function(g){e[g]&&(f[g]=e[g])});
return ye(a,f||{},!1)}
function Re(a,b){var c=b.format||"JSON";a=Se(a,b);var d=Te(a,b),e=!1,f=Ue(a,function(k){if(!e){e=!0;h&&window.clearTimeout(h);a:switch(k&&"status"in k?k.status:-1){case 200:case 201:case 202:case 203:case 204:case 205:case 206:case 304:var l=!0;break a;default:l=!1}var m=null,n=400<=k.status&&500>k.status,r=500<=k.status&&600>k.status;if(l||n||r)m=Ve(a,c,k,b.convertToSafeHtml);if(l)a:if(k&&204==k.status)l=!0;else{switch(c){case "XML":l=0==parseInt(m&&m.return_code,10);break a;case "RAW":l=!0;break a}l=
!!m}m=m||{};n=b.context||B;l?b.onSuccess&&b.onSuccess.call(n,k,m):b.onError&&b.onError.call(n,k,m);b.onFinish&&b.onFinish.call(n,k,m)}},b.method,d,b.headers,b.responseType,b.withCredentials);
if(b.onTimeout&&0<b.timeout){var g=b.onTimeout;var h=pe(function(){e||(e=!0,f.abort(),window.clearTimeout(h),g.call(b.context||B,f))},b.timeout)}}
function Se(a,b){b.includeDomain&&(a=document.location.protocol+"//"+document.location.hostname+(document.location.port?":"+document.location.port:"")+a);var c=S("XSRF_FIELD_NAME",void 0);if(b=b.urlParams)b[c]&&delete b[c],a=ye(a,b||{},!0);return a}
function Te(a,b){var c=S("XSRF_FIELD_NAME",void 0),d=S("XSRF_TOKEN",void 0),e=b.postBody||"",f=b.postParams,g=S("XSRF_FIELD_NAME",void 0),h;b.headers&&(h=b.headers["Content-Type"]);b.excludeXsrf||sb(a)&&!b.withCredentials&&sb(a)!=document.location.hostname||"POST"!=b.method||h&&"application/x-www-form-urlencoded"!=h||b.postParams&&b.postParams[g]||(f||(f={}),f[c]=d);f&&"string"===typeof e&&(e=xe(e),bb(e,f),e=b.postBodyFormat&&"JSON"==b.postBodyFormat?JSON.stringify(e):vb(e));if(!(a=e)&&(a=f)){a:{for(var k in f){f=
!1;break a}f=!0}a=!f}!Oe&&a&&"POST"!=b.method&&(Oe=!0,fe(Error("AJAX request with postData should use POST")));return e}
function Ve(a,b,c,d){var e=null;switch(b){case "JSON":try{var f=c.responseText}catch(g){throw d=Error("Error reading responseText"),d.params=a,ge(d),g;}a=c.getResponseHeader("Content-Type")||"";f&&0<=a.indexOf("json")&&(")]}'\n"===f.substring(0,5)&&(f=f.substring(5)),e=JSON.parse(f));break;case "XML":if(a=(a=c.responseXML)?We(a):null)e={},H(a.getElementsByTagName("*"),function(g){e[g.tagName]=Xe(g)})}d&&Ye(e);
return e}
function Ye(a){if(E(a))for(var b in a){var c;(c="html_content"==b)||(c=b.length-5,c=0<=c&&b.indexOf("_html",c)==c);if(c){c=b;var d=a[b];if(void 0===cb){var e=null;var f=B.trustedTypes;if(f&&f.createPolicy){try{e=f.createPolicy("goog#html",{createHTML:La,createScript:La,createScriptURL:La})}catch(g){B.console&&B.console.error(g.message)}cb=e}else cb=e}d=(e=cb)?e.createHTML(d):d;a[c]=new ob(d)}else Ye(a[b])}}
function We(a){return a?(a=("responseXML"in a?a.responseXML:a).getElementsByTagName("root"))&&0<a.length?a[0]:null:null}
function Xe(a){var b="";H(a.childNodes,function(c){b+=c.nodeValue});
return b}
function Ue(a,b,c,d,e,f,g){function h(){4==(k&&"readyState"in k?k.readyState:0)&&b&&ee(b)(k)}
c=void 0===c?"GET":c;d=void 0===d?"":d;var k=Le();if(!k)return null;"onloadend"in k?k.addEventListener("loadend",h,!1):k.onreadystatechange=h;T("debug_forward_web_query_parameters")&&(a=Qe(a));k.open(c,a,!0);f&&(k.responseType=f);g&&(k.withCredentials=!0);c="POST"==c&&(void 0===window.FormData||!(d instanceof FormData));if(e=Pe(a,e))for(var l in e)k.setRequestHeader(l,e[l]),"content-type"==l.toLowerCase()&&(c=!1);c&&k.setRequestHeader("Content-Type","application/x-www-form-urlencoded");k.send(d);
return k}
;var Ze=Ob||Pb;var $e={},af=0;function bf(a,b,c){c=void 0===c?"":c;if(cf(a,c))b&&b();else if(c=void 0===c?"":c,a)if(c)Ue(a,b,"POST",c,void 0);else if(S("USE_NET_AJAX_FOR_PING_TRANSPORT",!1))Ue(a,b,"GET","",void 0);else{b:{try{var d=new Na({url:a});if(d.j&&d.i||d.l){var e=rb(a.match(qb)[5]||null);var f=!(!e||!e.endsWith("/aclk")||"1"!==xb(a,"ri"));break b}}catch(g){}f=!1}f?cf(a)?(b&&b(),f=!0):f=!1:f=!1;f||df(a,b)}}
function cf(a,b){try{if(window.navigator&&window.navigator.sendBeacon&&window.navigator.sendBeacon(a,void 0===b?"":b))return!0}catch(c){}return!1}
function df(a,b){var c=new Image,d=""+af++;$e[d]=c;c.onload=c.onerror=function(){b&&$e[d]&&b();delete $e[d]};
c.src=a}
;var ef=B.ytPubsubPubsubInstance||new R,ff=B.ytPubsubPubsubSubscribedKeys||{},gf=B.ytPubsubPubsubTopicToKeys||{},hf=B.ytPubsubPubsubIsSynchronous||{};R.prototype.subscribe=R.prototype.subscribe;R.prototype.unsubscribeByKey=R.prototype.R;R.prototype.publish=R.prototype.M;R.prototype.clear=R.prototype.clear;F("ytPubsubPubsubInstance",ef);F("ytPubsubPubsubTopicToKeys",gf);F("ytPubsubPubsubIsSynchronous",hf);F("ytPubsubPubsubSubscribedKeys",ff);var jf=window,U=jf.ytcsi&&jf.ytcsi.now?jf.ytcsi.now:jf.performance&&jf.performance.timing&&jf.performance.now&&jf.performance.timing.navigationStart?function(){return jf.performance.timing.navigationStart+jf.performance.now()}:function(){return(new Date).getTime()};var kf=Be("initial_gel_batch_timeout",2E3),lf=Math.pow(2,16)-1,mf=null,nf=0,of=void 0,pf=0,qf=0,rf=0,sf=!0,tf=B.ytLoggingTransportGELQueue_||new Map;F("ytLoggingTransportGELQueue_",tf);var uf=B.ytLoggingTransportTokensToCttTargetIds_||{};F("ytLoggingTransportTokensToCttTargetIds_",uf);
function vf(a,b){if("log_event"===a.endpoint){var c="";a.V?c="visitorOnlyApprovedKey":a.F&&(uf[a.F.token]=wf(a.F),c=a.F.token);var d=tf.get(c)||[];tf.set(c,d);d.push(a.payload);b&&(of=new b);a=Be("tvhtml5_logging_max_batch")||Be("web_logging_max_batch")||100;b=U();d.length>=a?xf({writeThenSend:!0}):10<=b-rf&&(yf(),rf=b)}}
function zf(a,b){if("log_event"===a.endpoint){var c="";a.V?c="visitorOnlyApprovedKey":a.F&&(uf[a.F.token]=wf(a.F),c=a.F.token);var d=new Map;d.set(c,[a.payload]);b&&(of=new b);return new P(function(e){of&&of.isReady()?Af(d,e,{bypassNetworkless:!0}):e()})}}
function xf(a){a=void 0===a?{}:a;new P(function(b){window.clearTimeout(pf);window.clearTimeout(qf);qf=0;of&&of.isReady()?(Af(tf,b,a),tf.clear()):(yf(),b())})}
function yf(){T("web_gel_timeout_cap")&&!qf&&(qf=pe(function(){xf({writeThenSend:!0})},6E4));
window.clearTimeout(pf);var a=S("LOGGING_BATCH_TIMEOUT",Be("web_gel_debounce_ms",1E4));T("shorten_initial_gel_batch_timeout")&&sf&&(a=kf);pf=pe(function(){xf({writeThenSend:!0})},a)}
function Af(a,b,c){var d=of;c=void 0===c?{}:c;var e=Math.round(U()),f=a.size;a=u(a);for(var g=a.next();!g.done;g=a.next()){var h=u(g.value);g=h.next().value;var k=h.next().value;h=$a({context:Bf(d.h||Cf())});h.events=k;(k=uf[g])&&Df(h,g,k);delete uf[g];g="visitorOnlyApprovedKey"===g;Ef(h,e,g);T("send_beacon_before_gel")&&window.navigator&&window.navigator.sendBeacon&&!c.writeThenSend&&bf("/generate_204");Ff(d,"log_event",h,{retry:!0,onSuccess:function(){f--;f||b();nf=Math.round(U()-e)},
onError:function(){f--;f||b()},
ja:c,V:g});sf=!1}}
function Ef(a,b,c){a.requestTimeMs=String(b);T("unsplit_gel_payloads_in_logs")&&(a.unsplitGelPayloadsInLogs=!0);!c&&(b=S("EVENT_ID",void 0))&&((c=S("BATCH_CLIENT_COUNTER",void 0)||0)||(c=Math.floor(Math.random()*lf/2)),c++,c>lf&&(c=1),be("BATCH_CLIENT_COUNTER",c),b={serializedEventId:b,clientCounter:String(c)},a.serializedClientEventId=b,mf&&nf&&T("log_gel_rtt_web")&&(a.previousBatchInfo={serializedClientEventId:mf,roundtripMs:String(nf)}),mf=b,nf=0)}
function Df(a,b,c){if(c.videoId)var d="VIDEO";else if(c.playlistId)d="PLAYLIST";else return;a.credentialTransferTokenTargetId=c;a.context=a.context||{};a.context.user=a.context.user||{};a.context.user.credentialTransferTokens=[{token:b,scope:d}]}
function wf(a){var b={};a.videoId?b.videoId=a.videoId:a.playlistId&&(b.playlistId=a.playlistId);return b}
;var Gf=B.ytLoggingGelSequenceIdObj_||{};F("ytLoggingGelSequenceIdObj_",Gf);function Hf(){if(!B.matchMedia)return"WEB_DISPLAY_MODE_UNKNOWN";try{return B.matchMedia("(display-mode: standalone)").matches?"WEB_DISPLAY_MODE_STANDALONE":B.matchMedia("(display-mode: minimal-ui)").matches?"WEB_DISPLAY_MODE_MINIMAL_UI":B.matchMedia("(display-mode: fullscreen)").matches?"WEB_DISPLAY_MODE_FULLSCREEN":B.matchMedia("(display-mode: browser)").matches?"WEB_DISPLAY_MODE_BROWSER":"WEB_DISPLAY_MODE_UNKNOWN"}catch(a){return"WEB_DISPLAY_MODE_UNKNOWN"}}
;F("ytglobal.prefsUserPrefsPrefs_",D("ytglobal.prefsUserPrefsPrefs_")||{});var If={bluetooth:"CONN_DISCO",cellular:"CONN_CELLULAR_UNKNOWN",ethernet:"CONN_WIFI",none:"CONN_NONE",wifi:"CONN_WIFI",wimax:"CONN_CELLULAR_4G",other:"CONN_UNKNOWN",unknown:"CONN_UNKNOWN","slow-2g":"CONN_CELLULAR_2G","2g":"CONN_CELLULAR_2G","3g":"CONN_CELLULAR_3G","4g":"CONN_CELLULAR_4G"},Jf={"slow-2g":"EFFECTIVE_CONNECTION_TYPE_SLOW_2G","2g":"EFFECTIVE_CONNECTION_TYPE_2G","3g":"EFFECTIVE_CONNECTION_TYPE_3G","4g":"EFFECTIVE_CONNECTION_TYPE_4G"};
function Kf(){var a=B.navigator;return a?a.connection:void 0}
;function Lf(){return"INNERTUBE_API_KEY"in ae&&"INNERTUBE_API_VERSION"in ae}
function Cf(){return{innertubeApiKey:S("INNERTUBE_API_KEY",void 0),innertubeApiVersion:S("INNERTUBE_API_VERSION",void 0),sa:S("INNERTUBE_CONTEXT_CLIENT_CONFIG_INFO"),ta:S("INNERTUBE_CONTEXT_CLIENT_NAME","WEB"),innertubeContextClientVersion:S("INNERTUBE_CONTEXT_CLIENT_VERSION",void 0),wa:S("INNERTUBE_CONTEXT_HL",void 0),va:S("INNERTUBE_CONTEXT_GL",void 0),xa:S("INNERTUBE_HOST_OVERRIDE",void 0)||"",za:!!S("INNERTUBE_USE_THIRD_PARTY_AUTH",!1),ya:!!S("INNERTUBE_OMIT_API_KEY_WHEN_AUTH_HEADER_IS_PRESENT",
!1),appInstallData:S("SERIALIZED_CLIENT_CONFIG_DATA",void 0)}}
function Bf(a){var b={client:{hl:a.wa,gl:a.va,clientName:a.ta,clientVersion:a.innertubeContextClientVersion,configInfo:a.sa}},c=B.devicePixelRatio;c&&1!=c&&(b.client.screenDensityFloat=String(c));c=S("EXPERIMENTS_TOKEN","");""!==c&&(b.client.experimentsToken=c);c=[];var d=S("EXPERIMENTS_FORCED_FLAGS",{});for(e in d)c.push({key:e,value:String(d[e])});var e=S("EXPERIMENT_FLAGS",{});for(var f in e)f.startsWith("force_")&&void 0===d[f]&&c.push({key:f,value:String(e[f])});0<c.length&&(b.request={internalExperimentFlags:c});
f=b.client.clientName;if("WEB"===f||"MWEB"===f||1===f||2===f){if(!T("web_include_display_mode_killswitch")){var g;b.client.mainAppWebInfo=null!=(g=b.client.mainAppWebInfo)?g:{};b.client.mainAppWebInfo.webDisplayMode=Hf()}}else if(g=b.client.clientName,("WEB_REMIX"===g||76===g)&&!T("music_web_display_mode_killswitch")){var h;b.client.ia=null!=(h=b.client.ia)?h:{};b.client.ia.webDisplayMode=Hf()}a.appInstallData&&(b.client.configInfo=b.client.configInfo||{},b.client.configInfo.appInstallData=a.appInstallData);
S("DELEGATED_SESSION_ID")&&!T("pageid_as_header_web")&&(b.user={onBehalfOfUser:S("DELEGATED_SESSION_ID")});a:{if(h=Kf()){a=If[h.type||"unknown"]||"CONN_UNKNOWN";h=If[h.effectiveType||"unknown"]||"CONN_UNKNOWN";"CONN_CELLULAR_UNKNOWN"===a&&"CONN_UNKNOWN"!==h&&(a=h);if("CONN_UNKNOWN"!==a)break a;if("CONN_UNKNOWN"!==h){a=h;break a}}a=void 0}a&&(b.client.connectionType=a);T("web_log_effective_connection_type")&&(a=Kf(),a=null!==a&&void 0!==a&&a.effectiveType?Jf.hasOwnProperty(a.effectiveType)?Jf[a.effectiveType]:
"EFFECTIVE_CONNECTION_TYPE_UNKNOWN":void 0,a&&(b.client.effectiveConnectionType=a));a=Object;h=a.assign;g=b.client;f={};e=u(Object.entries(xe(S("DEVICE",""))));for(c=e.next();!c.done;c=e.next())d=u(c.value),c=d.next().value,d=d.next().value,"cbrand"===c?f.deviceMake=d:"cmodel"===c?f.deviceModel=d:"cbr"===c?f.browserName=d:"cbrver"===c?f.browserVersion=d:"cos"===c?f.osName=d:"cosver"===c?f.osVersion=d:"cplatform"===c&&(f.platform=d);b.client=h.call(a,g,f);return b}
function Mf(a,b,c){c=void 0===c?{}:c;var d={"X-Goog-Visitor-Id":c.visitorData||S("VISITOR_DATA","")};if(b&&b.includes("www.youtube-nocookie.com"))return d;(b=c.Pa||S("AUTHORIZATION"))||(a?b="Bearer "+D("gapi.auth.getToken")().Oa:b=lc([]));b&&(d.Authorization=b,d["X-Goog-AuthUser"]=S("SESSION_INDEX",0),T("pageid_as_header_web")&&(d["X-Goog-PageId"]=S("DELEGATED_SESSION_ID")));return d}
;function Nf(a){a=Object.assign({},a);delete a.Authorization;var b=lc();if(b){var c=new Dc;c.update(S("INNERTUBE_API_KEY",void 0));c.update(b);b=c.digest();c=3;Ea(b);void 0===c&&(c=0);if(!Sb){Sb={};for(var d="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),e=["+/=","+/","-_=","-_.","-_"],f=0;5>f;f++){var g=d.concat(e[f].split(""));Rb[f]=g;for(var h=0;h<g.length;h++){var k=g[h];void 0===Sb[k]&&(Sb[k]=h)}}}c=Rb[c];d=[];for(e=0;e<b.length;e+=3){var l=b[e],m=(f=e+1<b.length)?
b[e+1]:0;k=(g=e+2<b.length)?b[e+2]:0;h=l>>2;l=(l&3)<<4|m>>4;m=(m&15)<<2|k>>6;k&=63;g||(k=64,f||(m=64));d.push(c[h],c[l],c[m]||"",c[k]||"")}a.hash=d.join("")}return a}
;function Of(a){var b=new Ud;(b=b.isAvailable()?a?new $d(b,a):b:null)||(a=new Vd(a||"UserDataSharedStore"),b=a.isAvailable()?a:null);this.h=(a=b)?new Qd(a):null;this.i=document.domain||window.location.hostname}
Of.prototype.set=function(a,b,c,d){c=c||31104E3;this.remove(a);if(this.h)try{this.h.set(a,b,Date.now()+1E3*c);return}catch(f){}var e="";if(d)try{e=escape(td(b))}catch(f){return}else e=escape(b);b=this.i;ic.set(""+a,e,{aa:c,path:"/",domain:void 0===b?"youtube.com":b,secure:!1})};
Of.prototype.get=function(a,b){var c=void 0,d=!this.h;if(!d)try{c=this.h.get(a)}catch(e){d=!0}if(d&&(c=ic.get(""+a,void 0))&&(c=unescape(c),b))try{c=JSON.parse(c)}catch(e){this.remove(a),c=void 0}return c};
Of.prototype.remove=function(a){this.h&&this.h.remove(a);var b=this.i;ic.remove(""+a,"/",void 0===b?"youtube.com":b)};var Pf;function Qf(){Pf||(Pf=new Of("yt.innertube"));return Pf}
function Rf(a,b,c,d){if(d)return null;d=Qf().get("nextId",!0)||1;var e=Qf().get("requests",!0)||{};e[d]={method:a,request:b,authState:Nf(c),requestTime:Math.round(U())};Qf().set("nextId",d+1,86400,!0);Qf().set("requests",e,86400,!0);return d}
function Sf(a){var b=Qf().get("requests",!0)||{};delete b[a];Qf().set("requests",b,86400,!0)}
function Tf(a){var b=Qf().get("requests",!0);if(b){for(var c in b){var d=b[c];if(!(6E4>Math.round(U())-d.requestTime)){var e=d.authState,f=Nf(Mf(!1));Za(e,f)&&(e=d.request,"requestTimeMs"in e&&(e.requestTimeMs=Math.round(U())),Ff(a,d.method,e,{}));delete b[c]}}Qf().set("requests",b,86400,!0)}}
;var Uf=D("ytPubsub2Pubsub2Instance")||new R;R.prototype.subscribe=R.prototype.subscribe;R.prototype.unsubscribeByKey=R.prototype.R;R.prototype.publish=R.prototype.M;R.prototype.clear=R.prototype.clear;F("ytPubsub2Pubsub2Instance",Uf);F("ytPubsub2Pubsub2SubscribedKeys",D("ytPubsub2Pubsub2SubscribedKeys")||{});F("ytPubsub2Pubsub2TopicToKeys",D("ytPubsub2Pubsub2TopicToKeys")||{});F("ytPubsub2Pubsub2IsAsync",D("ytPubsub2Pubsub2IsAsync")||{});F("ytPubsub2Pubsub2SkipSubKey",null);var Vf=[],Wf=!1;function Xf(a,b){Wf||(Vf.push({type:"EVENT",eventType:a,payload:b}),10<Vf.length&&Vf.shift())}
;var Yf=function(){var a;return function(){a||(a=new Of("ytidb"));return a}}();
function Zf(){var a;return null===(a=Yf())||void 0===a?void 0:a.get("LAST_RESULT_ENTRY_KEY",!0)}
function $f(a,b,c){this.h=void 0===a?!1:a;this.failureMessage=b;this.j=c;(a=Zf())||(a={createdTimestampMs:U(),isSupported:this.h,resultCount:0,hasSucceededOnce:this.h});this.i=a;var d;if(ag()){var e;this.i.isSupported===this.h?e=Object.assign(Object.assign({},this.i),{resultCount:this.i.resultCount+1}):e={isSupported:this.h,resultCount:1,createdTimestampMs:U(),hasSucceededOnce:this.i.hasSucceededOnce||this.h};null===(d=Yf())||void 0===d?void 0:d.set("LAST_RESULT_ENTRY_KEY",e,2592E3,!0)}}
function bg(a,b){return new $f(!1,a instanceof Error?a.message:"",void 0===b?!1:b)}
$f.prototype.isSupported=function(){return this.h};
$f.prototype.log=function(){ag()&&Xf("IS_SUPPORTED_COMPLETED",{isSupported:this.h,lastIsSupported:this.i.isSupported,failureMessage:this.failureMessage,sameResultCount:this.i.resultCount,sameResultDurationMs:Math.floor(U()-this.i.createdTimestampMs),canDetectDataOnFailure:this.j})};
function ag(){var a;return!!(T("ytidb_analyze_is_supported")&&(null===(a=Yf())||void 0===a?0:a.h))}
;function cg(a,b){for(var c=[],d=1;d<arguments.length;++d)c[d-1]=arguments[d];d=Error.call(this,a);this.message=d.message;"stack"in d&&(this.stack=d.stack);d=[];var e=d.concat;if(!(c instanceof Array)){c=u(c);for(var f,g=[];!(f=c.next()).done;)g.push(f.value);c=g}this.args=e.call(d,c)}
ma(cg,Error);function dg(a){return a.substr(0,a.indexOf(":"))||a}
;var eg={},fg=(eg.AUTH_INVALID="No user identifier specified.",eg.EXPLICIT_ABORT="Transaction was explicitly aborted.",eg.IDB_NOT_SUPPORTED="IndexedDB is not supported.",eg.MISSING_OBJECT_STORE="Object store not created.",eg.UNKNOWN_ABORT="Transaction was aborted for unknown reasons.",eg.QUOTA_EXCEEDED="The current transaction exceeded its quota limitations.",eg.QUOTA_MAYBE_EXCEEDED="The current transaction may have failed because of exceeding quota limitations.",eg.EXECUTE_TRANSACTION_ON_CLOSED_DB=
"Can't start a transaction on a closed database",eg),gg={},hg=(gg.AUTH_INVALID="ERROR",gg.EXECUTE_TRANSACTION_ON_CLOSED_DB="WARNING",gg.EXPLICIT_ABORT="IGNORED",gg.IDB_NOT_SUPPORTED="ERROR",gg.MISSING_OBJECT_STORE="ERROR",gg.QUOTA_EXCEEDED="WARNING",gg.QUOTA_MAYBE_EXCEEDED="WARNING",gg.UNKNOWN_ABORT="WARNING",gg),ig={},jg=(ig.AUTH_INVALID=!1,ig.EXECUTE_TRANSACTION_ON_CLOSED_DB=!1,ig.EXPLICIT_ABORT=!1,ig.IDB_NOT_SUPPORTED=!1,ig.MISSING_OBJECT_STORE=!1,ig.QUOTA_EXCEEDED=!1,ig.QUOTA_MAYBE_EXCEEDED=!0,
ig.UNKNOWN_ABORT=!0,ig);function V(a,b,c,d,e){b=void 0===b?{}:b;c=void 0===c?fg[a]:c;d=void 0===d?hg[a]:d;e=void 0===e?jg[a]:e;cg.call(this,c,Object.assign({name:"YtIdbKnownError",isSw:void 0===self.document,isIframe:self!==self.top,type:a},b));this.type=a;this.message=c;this.level=d;this.h=e;Object.setPrototypeOf(this,V.prototype)}
ma(V,cg);function kg(a){V.call(this,"MISSING_OBJECT_STORE",{Ta:a},fg.MISSING_OBJECT_STORE);Object.setPrototypeOf(this,kg.prototype)}
ma(kg,V);var lg=["The database connection is closing","Can't start a transaction on a closed database","A mutation operation was attempted on a database that did not allow mutations"];
function mg(a,b,c){b=dg(b);var d=a instanceof Error?a:Error("Unexpected error: "+a);if(d instanceof V)return d;if("QuotaExceededError"===d.name)return new V("QUOTA_EXCEEDED",{objectStoreNames:c,dbName:b});if(Qb&&"UnknownError"===d.name)return new V("QUOTA_MAYBE_EXCEEDED",{objectStoreNames:c,dbName:b});if("InvalidStateError"===d.name&&lg.some(function(e){return d.message.includes(e)}))return new V("EXECUTE_TRANSACTION_ON_CLOSED_DB",{objectStoreNames:c,
dbName:b});if("AbortError"===d.name)return new V("UNKNOWN_ABORT",{objectStoreNames:c,dbName:b},d.message);d.args=[{name:"IdbError",Ua:d.name,dbName:b,objectStoreNames:c}];d.level="WARNING";return d}
;function ng(a){if(!a)throw Error();throw a;}
function og(a){return a}
function W(a){function b(e){if("PENDING"===d.state.status){d.state={status:"REJECTED",reason:e};e=u(d.onRejected);for(var f=e.next();!f.done;f=e.next())f=f.value,f()}}
function c(e){if("PENDING"===d.state.status){d.state={status:"FULFILLED",value:e};e=u(d.h);for(var f=e.next();!f.done;f=e.next())f=f.value,f()}}
var d=this;this.i=a;this.state={status:"PENDING"};this.h=[];this.onRejected=[];try{this.i(c,b)}catch(e){b(e)}}
W.all=function(a){return new W(function(b,c){var d=[],e=a.length;0===e&&b(d);for(var f={L:0};f.L<a.length;f={L:f.L},++f.L)pg(W.resolve(a[f.L]).then(function(g){return function(h){d[g.L]=h;e--;0===e&&b(d)}}(f)),function(g){c(g)})})};
W.resolve=function(a){return new W(function(b,c){a instanceof W?a.then(b,c):b(a)})};
W.reject=function(a){return new W(function(b,c){c(a)})};
W.prototype.then=function(a,b){var c=this,d=null!==a&&void 0!==a?a:og,e=null!==b&&void 0!==b?b:ng;return new W(function(f,g){"PENDING"===c.state.status?(c.h.push(function(){qg(c,c,d,f,g)}),c.onRejected.push(function(){rg(c,c,e,f,g)})):"FULFILLED"===c.state.status?qg(c,c,d,f,g):"REJECTED"===c.state.status&&rg(c,c,e,f,g)})};
function pg(a,b){a.then(void 0,b)}
function qg(a,b,c,d,e){try{if("FULFILLED"!==a.state.status)throw Error("calling handleResolve before the promise is fulfilled.");var f=c(a.state.value);f instanceof W?sg(a,b,f,d,e):d(f)}catch(g){e(g)}}
function rg(a,b,c,d,e){try{if("REJECTED"!==a.state.status)throw Error("calling handleReject before the promise is rejected.");var f=c(a.state.reason);f instanceof W?sg(a,b,f,d,e):d(f)}catch(g){e(g)}}
function sg(a,b,c,d,e){b===c?e(new TypeError("Circular promise chain detected.")):c.then(function(f){f instanceof W?sg(a,b,f,d,e):d(f)},function(f){e(f)})}
;function tg(a,b,c){function d(){c(a.error);f()}
function e(){b(a.result);f()}
function f(){try{a.removeEventListener("success",e),a.removeEventListener("error",d)}catch(g){}}
a.addEventListener("success",e);a.addEventListener("error",d)}
function ug(a){return new Promise(function(b,c){tg(a,b,c)})}
function X(a){return new W(function(b,c){tg(a,b,c)})}
;function vg(a,b){return new W(function(c,d){function e(){var f=a?b(a):null;f?f.then(function(g){a=g;e()},d):c()}
e()})}
;function wg(a,b){this.h=a;this.options=b;this.transactionCount=0;this.j=Math.round(U());this.i=!1}
p=wg.prototype;p.add=function(a,b,c){return xg(this,[a],{mode:"readwrite",K:!0},function(d){return yg(d,a).add(b,c)})};
p.clear=function(a){return xg(this,[a],{mode:"readwrite",K:!0},function(b){return yg(b,a).clear()})};
p.close=function(){var a;this.h.close();(null===(a=this.options)||void 0===a?0:a.closed)&&this.options.closed()};
p.count=function(a,b){return xg(this,[a],{mode:"readonly",K:!0},function(c){return yg(c,a).count(b)})};
p.delete=function(a,b){return xg(this,[a],{mode:"readwrite",K:!0},function(c){return yg(c,a).delete(b)})};
p.get=function(a,b){return xg(this,[a],{mode:"readonly",K:!0},function(c){return yg(c,a).get(b)})};
function xg(a,b,c,d){return L(a,function f(){var g=this,h,k,l,m,n,r,q,v,w,y,Q,K;return z(f,function(C){switch(C.h){case 1:var I={mode:"readonly",K:!1};"string"===typeof c?I.mode=c:I=c;h=I;g.transactionCount++;k=h.K?Be("ytidb_transaction_try_count",1):1;l=0;case 2:if(m){C.u(3);break}l++;n=Math.round(U());ra(C,4);r=g.h.transaction(b,h.mode);I=new zg(r);I=Ag(I,d);return x(C,I,6);case 6:return q=C.j,v=Math.round(U()),Bg(g,n,v,l,void 0,b.join(),h),C.return(q);case 4:w=sa(C);y=Math.round(U());Q=mg(w,g.h.name,
b.join());if((K=Q instanceof V&&!Q.h)||l>=k)Bg(g,n,y,l,Q,b.join(),h),m=Q;C.u(2);break;case 3:return C.return(Promise.reject(m))}})})}
function Bg(a,b,c,d,e,f,g){b=c-b;e?(e instanceof V&&("QUOTA_EXCEEDED"===e.type||"QUOTA_MAYBE_EXCEEDED"===e.type)&&Xf("QUOTA_EXCEEDED",{dbName:dg(a.h.name),objectStoreNames:f,transactionCount:a.transactionCount,transactionMode:g.mode}),e instanceof V&&"UNKNOWN_ABORT"===e.type&&(Xf("TRANSACTION_UNEXPECTEDLY_ABORTED",{objectStoreNames:f,transactionDuration:b,transactionCount:a.transactionCount,dbDuration:c-a.j}),a.i=!0),Cg(a,!1,d,f,b),Wf||(Vf.push({type:"ERROR",payload:e}),10<Vf.length&&Vf.shift())):
Cg(a,!0,d,f,b)}
function Cg(a,b,c,d,e){Xf("TRANSACTION_ENDED",{objectStoreNames:d,connectionHasUnknownAbortedTransaction:a.i,duration:e,isSuccessful:b,tryCount:c})}
function Dg(a){this.h=a}
p=Dg.prototype;p.add=function(a,b){return X(this.h.add(a,b))};
p.clear=function(){return X(this.h.clear()).then(function(){})};
p.count=function(a){return X(this.h.count(a))};
function Eg(a,b){return Fg(a,{query:b},function(c){return c.delete().then(function(){return c.continue()})}).then(function(){})}
p.delete=function(a){return a instanceof IDBKeyRange?Eg(this,a):X(this.h.delete(a))};
p.get=function(a){return X(this.h.get(a))};
p.index=function(a){return new Gg(this.h.index(a))};
p.getName=function(){return this.h.name};
function Fg(a,b,c){a=a.h.openCursor(b.query,b.direction);return Hg(a).then(function(d){return vg(d,c)})}
function zg(a){var b=this;this.h=a;this.i=new Map;this.aborted=!1;this.done=new Promise(function(c,d){b.h.addEventListener("complete",function(){c()});
b.h.addEventListener("error",function(e){e.currentTarget===e.target&&d(b.h.error)});
b.h.addEventListener("abort",function(){var e=b.h.error;if(e)d(e);else if(!b.aborted){e=V;for(var f=b.h.objectStoreNames,g=[],h=0;h<f.length;h++){var k=f.item(h);if(null===k)throw Error("Invariant: item in DOMStringList is null");g.push(k)}e=new e("UNKNOWN_ABORT",{objectStoreNames:g.join(),dbName:b.h.db.name,mode:b.h.mode});d(e)}})})}
function Ag(a,b){var c=new Promise(function(d,e){pg(b(a).then(function(f){a.commit();d(f)}),e)});
return Promise.all([c,a.done]).then(function(d){return u(d).next().value})}
zg.prototype.abort=function(){this.h.abort();this.aborted=!0;throw new V("EXPLICIT_ABORT");};
zg.prototype.commit=function(){var a=this.h;a.commit&&!this.aborted&&a.commit()};
function yg(a,b){b=a.h.objectStore(b);var c=a.i.get(b);c||(c=new Dg(b),a.i.set(b,c));return c}
function Gg(a){this.h=a}
Gg.prototype.count=function(a){return X(this.h.count(a))};
Gg.prototype.delete=function(a){return Ig(this,{query:a},function(b){return b.delete().then(function(){return b.continue()})})};
Gg.prototype.get=function(a){return X(this.h.get(a))};
Gg.prototype.getKey=function(a){return X(this.h.getKey(a))};
function Ig(a,b,c){a=a.h.openCursor(void 0===b.query?null:b.query,void 0===b.direction?"next":b.direction);return Hg(a).then(function(d){return vg(d,c)})}
function Jg(a,b){this.request=a;this.cursor=b}
function Hg(a){return X(a).then(function(b){return null===b?null:new Jg(a,b)})}
p=Jg.prototype;p.advance=function(a){this.cursor.advance(a);return Hg(this.request)};
p.continue=function(a){this.cursor.continue(a);return Hg(this.request)};
p.delete=function(){return X(this.cursor.delete()).then(function(){})};
p.getKey=function(){return this.cursor.key};
p.update=function(a){return X(this.cursor.update(a))};function Kg(a,b,c){return L(this,function e(){var f,g,h,k,l,m,n,r,q,v;return z(e,function(w){if(1==w.h)return f=self.indexedDB.open(a,b),g=c,h=g.blocked,k=g.blocking,l=g.Ca,m=g.upgrade,n=g.closed,q=function(){r||(r=new wg(f.result,{closed:n}));return r},f.addEventListener("upgradeneeded",function(y){if(null===y.newVersion)throw Error("Invariant: newVersion on IDbVersionChangeEvent is null");
if(null===f.transaction)throw Error("Invariant: transaction on IDbOpenDbRequest is null");y.dataLoss&&"none"!==y.dataLoss&&Xf("IDB_DATA_CORRUPTED",{reason:y.dataLossMessage||"unknown reason",dbName:dg(a)});var Q=q(),K=new zg(f.transaction);m&&m(Q,y.oldVersion,y.newVersion,K)}),h&&f.addEventListener("blocked",function(){h()}),x(w,ug(f),2);
v=w.j;k&&v.addEventListener("versionchange",function(){k(q())});
v.addEventListener("close",function(){Xf("IDB_UNEXPECTEDLY_CLOSED",{dbName:dg(a),dbVersion:v.version});l&&l()});
return w.return(q())})})}
function Lg(a,b){b=void 0===b?{}:b;return L(this,function d(){var e,f,g;return z(d,function(h){e=self.indexedDB.deleteDatabase(a);f=b;(g=f.blocked)&&e.addEventListener("blocked",function(){g()});
return x(h,ug(e),0)})})}
;function Mg(a){this.name="YtIdbMeta";this.options=a;this.i=!1}
function Ng(a,b,c){c=void 0===c?{}:c;c=void 0===c?{}:c;return Kg(a,b,c)}
Mg.prototype.delete=function(a){a=void 0===a?{}:a;return Lg(this.name,a)};
Mg.prototype.open=function(){var a=this;if(!this.h){var b,c=function(){a.h===b&&(a.h=void 0)},d={blocking:function(f){f.close()},
closed:c,Ca:c,upgrade:this.options.upgrade},e=function(){return L(a,function g(){var h=this,k,l,m;return z(g,function(n){switch(n.h){case 1:return ra(n,2),x(n,Ng(h.name,h.options.version,d),4);case 4:k=n.j;a:{var r=u(Object.keys(h.options.Ba));for(var q=r.next();!q.done;q=r.next())if(q=q.value,!k.h.objectStoreNames.contains(q)){r=q;break a}r=void 0}l=r;if(void 0===l){n.u(5);break}if(h.i){n.u(6);break}h.i=!0;return x(n,h.delete(),7);case 7:return n.return(e());case 6:throw new kg(l);case 5:return n.return(k);
case 2:m=sa(n);if(m instanceof DOMException?"VersionError"===m.name:"DOMError"in self&&m instanceof DOMError?"VersionError"===m.name:m instanceof Object&&"message"in m&&"An attempt was made to open a database using a lower version than the existing version."===m.message)return n.return(Ng(h.name,void 0,Object.assign(Object.assign({},d),{upgrade:void 0})));c();throw m;}})})};
this.h=b=e()}return this.h};var Og=new Mg({Ba:{databases:!0},upgrade:function(a,b){1>b&&a.h.createObjectStore("databases",{keyPath:"actualName"})}});
function Pg(a){return L(this,function c(){var d;return z(c,function(e){if(1==e.h)return x(e,Og.open(),2);d=e.j;return e.return(xg(d,["databases"],{K:!0,mode:"readwrite"},function(f){var g=yg(f,"databases");return g.get(a.actualName).then(function(h){if(h?a.actualName!==h.actualName||a.publicName!==h.publicName||a.userIdentifier!==h.userIdentifier||a.clearDataOnAuthChange!==h.clearDataOnAuthChange:1)return X(g.h.put(a,void 0)).then(function(){})})}))})})}
function Qg(){return L(this,function b(){var c;return z(b,function(d){if(1==d.h)return x(d,Og.open(),2);c=d.j;return d.return(c.delete("databases","yt-idb-test-do-not-use"))})})}
function Rg(){return L(this,function b(){var c,d;return z(b,function(e){if(1==e.h)return x(e,Og.open(),2);if(3!=e.h)return c=e.j,x(e,c.count("databases"),3);d=e.j;return e.return(0<d)})})}
;var Sg;
function Tg(){return L(this,function b(){var c,d,e,f,g;return z(b,function(h){switch(h.h){case 1:if(T("ytidb_is_supported_cache_success_result")&&(c=Zf(),null===c||void 0===c?0:c.hasSucceededOnce))return h.return(new $f(!0));var k;if(k=Ze)k=/WebKit\/([0-9]+)/.exec(lb),k=!!(k&&600<=parseInt(k[1],10));k&&(k=/WebKit\/([0-9]+)/.exec(lb),k=!(k&&602<=parseInt(k[1],10)));if(k)return h.return(bg(Error("YtIdb is not supported on iOS 8 or 9")));if(Cb)return h.return(bg(Error("YtIdb is not supported on Edge")));try{if(d=
self,!(d.indexedDB&&d.IDBIndex&&d.IDBKeyRange&&d.IDBObjectStore))return h.return(bg(Error("Non-prefixed indexedDB APIs are missing")))}catch(l){return h.return(bg(l))}if(!("IDBTransaction"in self&&"objectStoreNames"in IDBTransaction.prototype))return h.return(bg(Error("IDBTransaction.prototype.objectStoreNames is missing")));ra(h,2);e={actualName:"yt-idb-test-do-not-use",publicName:"yt-idb-test-do-not-use",userIdentifier:void 0};return x(h,Pg(e),4);case 4:return x(h,Qg(),5);case 5:return h.return(new $f(!0));
case 2:f=sa(h);if(!ag()){h.u(6);break}ra(h,7);return x(h,Rg(),9);case 9:return g=h.j,h.return(bg(f,g));case 7:return sa(h),h.return(bg(f));case 6:return h.return(bg(f))}})})}
function Ug(){if(void 0!==Sg)return Sg;Wf=!0;return Sg=Tg().then(function(a){Wf=!1;a.log();return a.isSupported()})}
;var Vg;function Wg(){Vg||(Vg=new Of("yt.offline"));return Vg}
function Xg(){if(T("offline_error_handling")){var a=Wg().get("errors",!0);if(a){for(var b in a)if(a[b]){var c=new cg(b,"sent via offline_errors");c.name=a[b].name;c.stack=a[b].stack;c.level=a[b].level;fe(c)}Wg().set("errors",{},2592E3,!0)}}}
;var Yg=Be("network_polling_interval",3E4);function Zg(){N.call(this);this.S=0;this.o=this.j=!1;this.v=0;this.l=this.N=!1;this.h=$g();this.l=T("validate_network_status");ah(this);bh(this)}
ma(Zg,N);function ch(a,b){a.j=!0;if(void 0===b?0:b)a.S||dh(a)}
function $g(){var a=window.navigator.onLine;return void 0===a?!0:a}
function bh(a){window.addEventListener("online",function(){return L(a,function c(){var d=this;return z(c,function(e){if(1==e.h)return d.l?x(e,eh(d),2):(d.h=!0,d.j&&O(d,"ytnetworkstatus-online"),e.u(2));fh(d);d.N&&Xg();e.h=0})})})}
function ah(a){window.addEventListener("offline",function(){return L(a,function c(){var d=this;return z(c,function(e){if(1==e.h)return d.l?x(e,eh(d),2):(d.h=!1,d.j&&O(d,"ytnetworkstatus-offline"),e.u(2));fh(d);e.h=0})})})}
function dh(a){a.S=De(function(){return L(a,function c(){var d=this;return z(c,function(e){if(1==e.h){if(T("trigger_nsm_validation_checks_with_nwl")&&!d.h)return x(e,eh(d),3);if($g()){if(!1!==d.h)return e.u(3);d.o=!0;d.v=U();return d.j?d.l?x(e,eh(d),11):(d.h=!0,O(d,"ytnetworkstatus-online"),e.u(11)):e.u(11)}if(!0!==d.h)return e.u(3);d.o=!0;d.v=U();return d.j?d.l?x(e,eh(d),3):(d.h=!1,O(d,"ytnetworkstatus-offline"),e.u(3)):e.u(3)}if(3!=e.h)return d.N&&Xg(),e.u(3);dh(d);e.h=0})})},Yg)}
function fh(a){a.o&&(ge(new cg("NetworkStatusManager state did not match poll",U()-a.v)),a.o=!1)}
function eh(a){return a.B?a.B:a.B=new Promise(function(b){return L(a,function d(){var e,f,g,h=this;return z(d,function(k){switch(k.h){case 1:return e=new AbortController,f=e.signal,g=!1,ra(k,2,3),h.Y=Fe(function(){e.abort()},2E4),x(k,fetch("/generate_204",{method:"HEAD",
signal:f}),5);case 5:g=!0;case 3:ta(k);h.B=void 0;He(h.Y);g!==h.h&&(h.h=g,h.h&&h.j?O(h,"ytnetworkstatus-online"):h.j&&O(h,"ytnetworkstatus-offline"));b(g);ua(k);break;case 2:sa(k),g=!1,k.u(3)}})})})}
;function gh(a){a=void 0===a?{}:a;N.call(this);var b=this;this.j=this.o=0;Zg.h||(Zg.h=new Zg);this.h=Zg.h;ch(this.h,a.ra);a.Aa&&(this.h.N=!0);a.X?(this.X=a.X,jd(this.h,"ytnetworkstatus-online",function(){hh(b,"publicytnetworkstatus-online")}),jd(this.h,"ytnetworkstatus-offline",function(){hh(b,"publicytnetworkstatus-offline")})):(jd(this.h,"ytnetworkstatus-online",function(){O(b,"publicytnetworkstatus-online")}),jd(this.h,"ytnetworkstatus-offline",function(){O(b,"publicytnetworkstatus-offline")}))}
ma(gh,N);function ih(){jh||(jh=new gh({Aa:!0,ra:T("trigger_nsm_validation_checks_with_nwl")}));var a=jh.h;a.l||a.h===$g()||ge(new cg("NetworkStatusManager isOnline does not match window status"))}
function hh(a,b){a.X?a.j?(He(a.o),a.o=Fe(function(){a.l!==b&&(O(a,b),a.l=b,a.j=U())},a.X-(U()-a.j))):(O(a,b),a.l=b,a.j=U()):O(a,b)}
;var jh;function kh(a,b){b=void 0===b?{}:b;T("skip_is_supported_killswitch")?Ug().then(function(){ih();lh(a,b)}):(ih(),lh(a,b))}
function mh(a,b){b=void 0===b?{}:b;T("skip_is_supported_killswitch")?Ug().then(function(){lh(a,b)}):lh(a,b)}
function lh(a,b){if(T("networkless_with_beacon")){var c=["method","postBody"];if(Object.keys(b).length>c.length)var d=!0;else{d=0;c=u(c);for(var e=c.next();!e.done;e=c.next())b.hasOwnProperty(e.value)&&d++;d=Object.keys(b).length!==d}d?Re(a,b):bf(a,void 0,b.postBody)}else Re(a,b)}
;function nh(a){var b=this;this.h=null;a?this.h=a:Lf()&&(this.h=Cf());De(function(){Tf(b)},5E3)}
nh.prototype.isReady=function(){!this.h&&Lf()&&(this.h=Cf());return!!this.h};
function Ff(a,b,c,d){!S("VISITOR_DATA")&&"visitor_id"!==b&&.01>Math.random()&&ge(new cg("Missing VISITOR_DATA when sending innertube request.",b,c,d));if(!a.isReady()){var e=new cg("innertube xhrclient not ready",b,c,d);fe(e);throw e;}var f={headers:{"Content-Type":"application/json"},method:"POST",postParams:c,postBodyFormat:"JSON",onTimeout:function(){d.onTimeout()},
onFetchTimeout:d.onTimeout,onSuccess:function(n,r){if(d.onSuccess)d.onSuccess(r)},
onFetchSuccess:function(n){if(d.onSuccess)d.onSuccess(n)},
onError:function(n,r){if(d.onError)d.onError(r)},
onFetchError:function(n){if(d.onError)d.onError(n)},
timeout:d.timeout,withCredentials:!0},g="";(e=a.h.xa)&&(g=e);var h=a.h.za||!1,k=Mf(h,g,d);Object.assign(f.headers,k);f.headers.Authorization&&!g&&(f.headers["x-origin"]=window.location.origin);e="/youtubei/"+a.h.innertubeApiVersion+"/"+b;var l={alt:"json"};a.h.ya&&f.headers.Authorization||(l.key=a.h.innertubeApiKey);var m=ye(""+g+e,l||{},!0);(function(n){n=void 0===n?!1:n;var r;if(d.retry&&"www.youtube-nocookie.com"!=g&&(n||(r=Rf(b,c,k,h)),r)){var q=f.onSuccess,v=f.onFetchSuccess;f.onSuccess=function(w,
y){Sf(r);q(w,y)};
c.onFetchSuccess=function(w,y){Sf(r);v(w,y)}}try{n&&d.retry&&!d.ja.bypassNetworkless?(f.method="POST",!d.ja.writeThenSend&&T("nwl_send_fast_on_unload")?mh(m,f):kh(m,f)):(f.method="POST",f.postParams||(f.postParams={}),Re(m,f))}catch(w){if("InvalidAccessError"==w.name)r&&(Sf(r),r=0),ge(Error("An extension is blocking network request."));
else throw w;}r&&De(function(){Tf(a)},5E3)})(!1)}
;function oh(a,b){var c=void 0===c?{}:c;var d=nh;S("ytLoggingEventsDefaultDisabled",!1)&&nh==nh&&(d=null);c=void 0===c?{}:c;var e={},f=Math.round(c.timestamp||U());e.eventTimeMs=f<Number.MAX_SAFE_INTEGER?f:0;e[a]=b;a=D("_lact",window);a=null==a?-1:Math.max(Date.now()-a,0);e.context={lastActivityMs:String(c.timestamp||!isFinite(a)?-1:a)};T("log_sequence_info_on_gel_web")&&c.la&&(a=e.context,b=c.la,Gf[b]=b in Gf?Gf[b]+1:0,a.sequence={index:Gf[b],groupKey:b},c.Ra&&delete Gf[c.la]);(c.Wa?zf:vf)({endpoint:"log_event",
payload:e,F:c.F,V:c.V},d)}
;var ph=[{ha:function(a){return"Cannot read property '"+a.key+"'"},
ba:{TypeError:[{regexp:/Cannot read property '([^']+)' of (null|undefined)/,groups:["key","value"]},{regexp:/\u65e0\u6cd5\u83b7\u53d6\u672a\u5b9a\u4e49\u6216 (null|undefined) \u5f15\u7528\u7684\u5c5e\u6027\u201c([^\u201d]+)\u201d/,groups:["value","key"]},{regexp:/\uc815\uc758\ub418\uc9c0 \uc54a\uc74c \ub610\ub294 (null|undefined) \ucc38\uc870\uc778 '([^']+)' \uc18d\uc131\uc744 \uac00\uc838\uc62c \uc218 \uc5c6\uc2b5\ub2c8\ub2e4./,groups:["value","key"]},{regexp:/No se puede obtener la propiedad '([^']+)' de referencia nula o sin definir/,
groups:["key"]},{regexp:/Unable to get property '([^']+)' of (undefined or null) reference/,groups:["key","value"]}],Error:[{regexp:/(Permission denied) to access property "([^']+)"/,groups:["reason","key"]}]}},{ha:function(a){return"Cannot call '"+a.key+"'"},
ba:{TypeError:[{regexp:/(?:([^ ]+)?\.)?([^ ]+) is not a function/,groups:["base","key"]},{regexp:/([^ ]+) called on (null or undefined)/,groups:["key","value"]},{regexp:/Object (.*) has no method '([^ ]+)'/,groups:["base","key"]},{regexp:/Object doesn't support property or method '([^ ]+)'/,groups:["key"]},{regexp:/\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u306f '([^']+)' \u30d7\u30ed\u30d1\u30c6\u30a3\u307e\u305f\u306f\u30e1\u30bd\u30c3\u30c9\u3092\u30b5\u30dd\u30fc\u30c8\u3057\u3066\u3044\u307e\u305b\u3093/,
groups:["key"]},{regexp:/\uac1c\uccb4\uac00 '([^']+)' \uc18d\uc131\uc774\ub098 \uba54\uc11c\ub4dc\ub97c \uc9c0\uc6d0\ud558\uc9c0 \uc54a\uc2b5\ub2c8\ub2e4./,groups:["key"]}]}}];var rh={I:[],H:[{oa:qh,weight:500}]};function qh(a){a=a.stack;return a.includes("chrome://")||a.includes("chrome-extension://")||a.includes("moz-extension://")}
;function sh(){this.H=[];this.I=[]}
var th;function uh(){if(!th){var a=th=new sh;a.I.length=0;a.H.length=0;rh.I&&a.I.push.apply(a.I,rh.I);rh.H&&a.H.push.apply(a.H,rh.H)}return th}
;var vh=new R;function wh(a){function b(){return a.charCodeAt(d++)}
var c=a.length,d=0;do{var e=xh(b);if(Infinity===e)break;var f=e>>3;switch(e&7){case 0:e=xh(b);if(2===f)return e;break;case 1:if(2===f)return;d+=8;break;case 2:e=xh(b);if(2===f)return a.substr(d,e);d+=e;break;case 5:if(2===f)return;d+=4;break;default:return}}while(d<c)}
function xh(a){var b=a(),c=b&127;if(128>b)return c;b=a();c|=(b&127)<<7;if(128>b)return c;b=a();c|=(b&127)<<14;if(128>b)return c;b=a();return 128>b?c|(b&127)<<21:Infinity}
;function yh(a,b,c,d){if(a)if(Array.isArray(a)){var e=d;for(d=0;d<a.length&&!(a[d]&&(e+=zh(d,a[d],b,c),500<e));d++);d=e}else if("object"===typeof a)for(e in a){if(a[e]){var f=e;var g=a[e],h=b,k=c;f="string"!==typeof g||"clickTrackingParams"!==f&&"trackingParams"!==f?0:(g=wh(atob(g.replace(/-/g,"+").replace(/_/g,"/"))))?zh(f+".ve",g,h,k):0;d+=f;d+=zh(e,a[e],b,c);if(500<d)break}}else c[b]=Ah(a),d+=c[b].length;else c[b]=Ah(a),d+=c[b].length;return d}
function zh(a,b,c,d){c+="."+a;a=Ah(b);d[c]=a;return c.length+a.length}
function Ah(a){return("string"===typeof a?a:String(JSON.stringify(a))).substr(0,500)}
;var Bh=new Set,Ch=0,Dh=0,Eh=0,Fh=[],Gh=["PhantomJS","Googlebot","TO STOP THIS SECURITY SCAN go/scan"];var Hh={};function Ih(a){return Hh[a]||(Hh[a]=String(a).replace(/\-([a-z])/g,function(b,c){return c.toUpperCase()}))}
;var Jh={},Kh=[],Kd=new R,Lh={};function Mh(){for(var a=u(Kh),b=a.next();!b.done;b=a.next())b=b.value,b()}
function Nh(a,b){var c;"yt:"===a.tagName.toLowerCase().substr(0,3)?c=a.getAttribute(b):c=a?a.dataset?a.dataset[Ih(b)]:a.getAttribute("data-"+b):null;return c}
function Oh(a,b){for(var c=1;c<arguments.length;++c);Kd.M.apply(Kd,arguments)}
;function Ph(a){this.j=this.h=!1;this.i=a||{};a=document.getElementById("www-widgetapi-script");if(this.h=!!("https:"===document.location.protocol||a&&0===a.src.indexOf("https:"))){a=[this.i,window.YTConfig||{}];for(var b=0;b<a.length;b++)a[b].host&&(a[b].host=a[b].host.toString().replace("http://","https://"))}}
function Y(a,b){a=[a.i,window.YTConfig||{}];for(var c=0;c<a.length;c++){var d=a[c][b];if(void 0!==d)return d}return null}
function Qh(a,b,c){Rh||(Rh={},oe(window,"message",function(d){a:{if(d.origin===Y(a,"host")||d.origin===Y(a,"host").toString().replace(/^http:/,"https:")){try{var e=JSON.parse(d.data)}catch(f){e=void 0;break a}a.j=!0;a.h||0!==d.origin.indexOf("https:")||(a.h=!0);if(d=Rh[e.id])d.o=!0,d.o&&(H(d.s,d.sendMessage,d),d.s.length=0),d.ca(e)}e=void 0}return e}));
Rh[c]=b}
var Rh=null;function Z(a,b,c){this.m=this.h=this.i=null;this.j=0;this.o=!1;this.s=[];this.l=null;this.B={};if(!a)throw Error("YouTube player element ID required.");this.id=Fa(this);this.v=c;this.setup(a,b)}
p=Z.prototype;p.setSize=function(a,b){this.h.width=a.toString();this.h.height=b.toString();return this};
p.na=function(){return this.h};
p.ca=function(a){Sh(this,a.event,a)};
p.addEventListener=function(a,b){var c=b;"string"===typeof b&&(c=function(){window[b].apply(window,arguments)});
if(!c)return this;this.l.subscribe(a,c);Th(this,a);return this};
function Uh(a,b){b=b.split(".");if(2===b.length){var c=b[1];a.v===b[0]&&Th(a,c)}}
p.destroy=function(){this.h&&this.h.id&&(Jh[this.h.id]=null);var a=this.l;a&&"function"==typeof a.dispose&&a.dispose();if(this.m){a=this.h;var b=a.parentNode;b&&b.replaceChild(this.m,a)}else(a=this.h)&&a.parentNode&&a.parentNode.removeChild(a);Rh&&(Rh[this.id]=null);this.i=null;a=this.h;for(var c in Ya)Ya[c][0]==a&&me(c);this.m=this.h=null};
p.ea=function(){return{}};
function Vh(a,b,c){c=c||[];c=Array.prototype.slice.call(c);b={event:"command",func:b,args:c};a.o?a.sendMessage(b):a.s.push(b)}
function Sh(a,b,c){a.l.m||(c={target:a,data:c},a.l.M(b,c),Oh(a.v+"."+b,c))}
function Wh(a,b){var c=document.createElement("iframe");b=b.attributes;for(var d=0,e=b.length;d<e;d++){var f=b[d].value;null!=f&&""!==f&&"null"!==f&&c.setAttribute(b[d].name,f)}c.setAttribute("frameBorder","0");c.setAttribute("allowfullscreen","1");c.setAttribute("allow","accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture");c.setAttribute("title","YouTube "+Y(a.i,"title"));(b=Y(a.i,"width"))&&c.setAttribute("width",b.toString());(b=Y(a.i,"height"))&&c.setAttribute("height",
b.toString());var g=a.ea();g.enablejsapi=window.postMessage?1:0;window.location.host&&(g.origin=window.location.protocol+"//"+window.location.host);g.widgetid=a.id;window.location.href&&H(["debugjs","debugcss"],function(h){var k=xb(window.location.href,h);null!==k&&(g[h]=k)});
window.yt_embedsTokenValue&&(g.embedsTokenValue=encodeURIComponent(window.yt_embedsTokenValue),delete window.yt_embedsTokenValue);c.src=Y(a.i,"host")+("/embed/"+Y(a.i,"videoId"))+"?"+vb(g);return c}
p.ka=function(){this.h&&this.h.contentWindow?this.sendMessage({event:"listening"}):window.clearInterval(this.j)};
function Xh(a){Qh(a.i,a,a.id);a.j=qe(a.ka.bind(a));oe(a.h,"load",function(){window.clearInterval(a.j);a.j=qe(a.ka.bind(a))})}
p.setup=function(a,b){var c=document;if(a="string"===typeof a?c.getElementById(a):a)if(c="iframe"===a.tagName.toLowerCase(),b.host||(b.host=c?tb(a.src):"https://www.youtube.com"),this.i=new Ph(b),c||(b=Wh(this,a),this.m=a,(c=a.parentNode)&&c.replaceChild(b,a),a=b),this.h=a,this.h.id||(this.h.id="widget"+Fa(this.h)),Jh[this.h.id]=this,window.postMessage){this.l=new R;Xh(this);b=Y(this.i,"events");for(var d in b)b.hasOwnProperty(d)&&this.addEventListener(d,b[d]);for(var e in Lh)Lh.hasOwnProperty(e)&&
Uh(this,e)}};
function Th(a,b){a.B[b]||(a.B[b]=!0,Vh(a,"addEventListener",[b]))}
p.sendMessage=function(a){a.id=this.id;a.channel="widget";a=td(a);var b=this.i;var c=tb(this.h.src||"");b=0===c.indexOf("https:")?[c]:b.h?[c.replace("http:","https:")]:b.j?[c]:[c,c.replace("http:","https:")];if(this.h.contentWindow)for(c=0;c<b.length;c++)try{this.h.contentWindow.postMessage(a,b[c])}catch(y){if(y.name&&"SyntaxError"===y.name){if(!(y.message&&0<y.message.indexOf("target origin ''"))){var d=void 0,e=y;d=void 0===d?{}:d;d.name=S("INNERTUBE_CONTEXT_CLIENT_NAME",1);d.version=S("INNERTUBE_CONTEXT_CLIENT_VERSION",
void 0);var f=d||{};d="WARNING";d=void 0===d?"ERROR":d;if(e){e.hasOwnProperty("level")&&e.level&&(d=e.level);if(T("console_log_js_exceptions")){var g=e,h=[];h.push("Name: "+g.name);h.push("Message: "+g.message);g.hasOwnProperty("params")&&h.push("Error Params: "+JSON.stringify(g.params));g.hasOwnProperty("args")&&h.push("Error args: "+JSON.stringify(g.args));h.push("File name: "+g.fileName);h.push("Stacktrace: "+g.stack);window.console.log(h.join("\n"),g)}if(!(5<=Ch)){g=void 0;var k=f,l=Fc(e);f=l.message||
"Unknown Error";h=l.name||"UnknownError";var m=l.stack||e.i||"Not available";if(m.startsWith(h+": "+f)){var n=m.split("\n");n.shift();m=n.join("\n")}n=l.lineNumber||"Not available";l=l.fileName||"Not available";var r=0;if(e.hasOwnProperty("args")&&e.args&&e.args.length)for(g=0;g<e.args.length&&!(r=yh(e.args[g],"params."+g,k,r),500<=r);g++);else if(e.hasOwnProperty("params")&&e.params){var q=e.params;if("object"===typeof e.params)for(g in q){if(q[g]){var v="params."+g,w=Ah(q[g]);k[v]=w;r+=v.length+
w.length;if(500<r)break}}else k.params=Ah(q)}if(Fh.length)for(g=0;g<Fh.length&&!(r=yh(Fh[g],"params.context."+g,k,r),500<=r);g++);navigator.vendor&&!k.hasOwnProperty("vendor")&&(k["device.vendor"]=navigator.vendor);g={message:f,name:h,lineNumber:n,fileName:l,stack:m,params:k,sampleWeight:1};f=Number(e.columnNumber);isNaN(f)||(g.lineNumber=g.lineNumber+":"+f);if("IGNORED"===e.level)e=0;else a:{e=uh();f=u(e.I);for(h=f.next();!h.done;h=f.next())if(h=h.value,g.message&&g.message.match(h.Sa)){e=h.weight;
break a}e=u(e.H);for(f=e.next();!f.done;f=e.next())if(f=f.value,f.oa(g)){e=f.weight;break a}e=1}g.sampleWeight=e;e=g;g=u(ph);for(f=g.next();!f.done;f=g.next())if(f=f.value,f.ba[e.name])for(n=u(f.ba[e.name]),h=n.next();!h.done;h=n.next())if(l=h.value,h=e.message.match(l.regexp)){e.params["params.error.original"]=h[0];n=l.groups;l={};for(m=0;m<n.length;m++)l[n[m]]=h[m+1],e.params["params.error."+n[m]]=h[m+1];e.message=f.ha(l);break}e.params||(e.params={});g=uh();e.params["params.errorServiceSignature"]=
"msg="+g.I.length+"&cb="+g.H.length;e.params["params.serviceWorker"]="false";B.document&&B.document.querySelectorAll&&(e.params["params.fscripts"]=String(document.querySelectorAll("script:not([nonce])").length));window.yterr&&"function"===typeof window.yterr&&window.yterr(e);if(0!==e.sampleWeight&&!Bh.has(e.message)){"ERROR"===d?(vh.M("handleError",e),T("record_app_crashed_web")&&0===Eh&&1===e.sampleWeight&&(Eh++,oh("appCrashed",{appCrashType:"APP_CRASH_TYPE_BREAKPAD"})),Dh++):"WARNING"===d&&vh.M("handleWarning",
e);if(T("kevlar_gel_error_routing")){g=d;h=e;b:{f=u(Gh);for(n=f.next();!n.done;n=f.next())if((l=lb)&&0<=l.toLowerCase().indexOf(n.value.toLowerCase())){f=!0;break b}f=!1}if(f)f=void 0;else{n={stackTrace:h.stack};h.fileName&&(n.filename=h.fileName);f=h.lineNumber&&h.lineNumber.split?h.lineNumber.split(":"):[];0!==f.length&&(1!==f.length||isNaN(Number(f[0]))?2!==f.length||isNaN(Number(f[0]))||isNaN(Number(f[1]))||(n.lineNumber=Number(f[0]),n.columnNumber=Number(f[1])):n.lineNumber=Number(f[0]));f={level:"ERROR_LEVEL_UNKNOWN",
message:h.message,errorClassName:h.name,sampleWeight:h.sampleWeight};"ERROR"===g?f.level="ERROR_LEVEL_ERROR":"WARNING"===g&&(f.level="ERROR_LEVEL_WARNNING");n={isObfuscated:!0,browserStackInfo:n};l={pageUrl:window.location.href,kvPairs:[]};S("FEXP_EXPERIMENTS")&&(l.experimentIds=S("FEXP_EXPERIMENTS"));if(h=h.params)for(m=u(Object.keys(h)),k=m.next();!k.done;k=m.next())k=k.value,l.kvPairs.push({key:"client."+k,value:String(h[k])});h=S("SERVER_NAME",void 0);m=S("SERVER_VERSION",void 0);h&&m&&(l.kvPairs.push({key:"server.name",
value:h}),l.kvPairs.push({key:"server.version",value:m}));f={errorMetadata:l,stackTrace:n,logMessage:f}}f&&(oh("clientError",f),("ERROR"===g||T("errors_flush_gel_always_killswitch"))&&xf())}if(!T("suppress_error_204_logging")){f=e;g=f.params||{};d={urlParams:{a:"logerror",t:"jserror",type:f.name,msg:f.message.substr(0,250),line:f.lineNumber,level:d,"client.name":g.name},postParams:{url:S("PAGE_NAME",window.location.href),file:f.fileName},method:"POST"};g.version&&(d["client.version"]=g.version);if(d.postParams){f.stack&&
(d.postParams.stack=f.stack);f=u(Object.keys(g));for(h=f.next();!h.done;h=f.next())h=h.value,d.postParams["client."+h]=g[h];if(g=S("LATEST_ECATCHER_SERVICE_TRACKING_PARAMS",void 0))for(f=u(Object.keys(g)),h=f.next();!h.done;h=f.next())h=h.value,d.postParams[h]=g[h];g=S("SERVER_NAME",void 0);f=S("SERVER_VERSION",void 0);g&&f&&(d.postParams["server.name"]=g,d.postParams["server.version"]=f)}Re(S("ECATCHER_REPORT_HOST","")+"/error_204",d)}Bh.add(e.message);Ch++}}}}}else throw y;}else console&&console.warn&&
console.warn("The YouTube player is not attached to the DOM. API calls should be made after the onReady event. See more: https://developers.google.com/youtube/iframe_api_reference#Events")};function Yh(a){return(0===a.search("cue")||0===a.search("load"))&&"loadModule"!==a}
function Zh(a){return 0===a.search("get")||0===a.search("is")}
;function $h(a,b){Z.call(this,a,Object.assign({title:"video player",videoId:"",width:640,height:360},b||{}),"player");this.C={};this.playerInfo={}}
ma($h,Z);p=$h.prototype;p.ea=function(){var a=Y(this.i,"playerVars");if(a){var b={},c;for(c in a)b[c]=a[c];a=b}else a={};window!==window.top&&document.referrer&&(a.widget_referrer=document.referrer.substring(0,256));if(c=Y(this.i,"embedConfig")){if(E(c))try{c=JSON.stringify(c)}catch(d){console.error("Invalid embed config JSON",d)}a.embed_config=c}return a};
p.ca=function(a){var b=a.event;a=a.info;switch(b){case "apiInfoDelivery":if(E(a))for(var c in a)a.hasOwnProperty(c)&&(this.C[c]=a[c]);break;case "infoDelivery":ai(this,a);break;case "initialDelivery":E(a)&&(window.clearInterval(this.j),this.playerInfo={},this.C={},bi(this,a.apiInterface),ai(this,a));break;default:Sh(this,b,a)}};
function ai(a,b){if(E(b))for(var c in b)b.hasOwnProperty(c)&&(a.playerInfo[c]=b[c])}
function bi(a,b){H(b,function(c){this[c]||("getCurrentTime"===c?this[c]=function(){var d=this.playerInfo.currentTime;if(1===this.playerInfo.playerState){var e=(Date.now()/1E3-this.playerInfo.currentTimeLastUpdated_)*this.playerInfo.playbackRate;0<e&&(d+=Math.min(e,1))}return d}:Yh(c)?this[c]=function(){this.playerInfo={};
this.C={};Vh(this,c,arguments);return this}:Zh(c)?this[c]=function(){var d=0;
0===c.search("get")?d=3:0===c.search("is")&&(d=2);return this.playerInfo[c.charAt(d).toLowerCase()+c.substr(d+1)]}:this[c]=function(){Vh(this,c,arguments);
return this})},a)}
p.getVideoEmbedCode=function(){var a=Y(this.i,"host")+("/embed/"+Y(this.i,"videoId")),b=Number(Y(this.i,"width")),c=Number(Y(this.i,"height"));if(isNaN(b)||isNaN(c))throw Error("Invalid width or height property");b=Math.floor(b);c=Math.floor(c);kb.test(a)&&(-1!=a.indexOf("&")&&(a=a.replace(eb,"&amp;")),-1!=a.indexOf("<")&&(a=a.replace(fb,"&lt;")),-1!=a.indexOf(">")&&(a=a.replace(gb,"&gt;")),-1!=a.indexOf('"')&&(a=a.replace(hb,"&quot;")),-1!=a.indexOf("'")&&(a=a.replace(ib,"&#39;")),-1!=a.indexOf("\x00")&&
(a=a.replace(jb,"&#0;")));return'<iframe width="'+b+'" height="'+c+'" src="'+a+'" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>'};
p.getOptions=function(a){return this.C.namespaces?a?this.C[a]?this.C[a].options||[]:[]:this.C.namespaces||[]:[]};
p.getOption=function(a,b){if(this.C.namespaces&&a&&b&&this.C[a])return this.C[a][b]};
function ci(a){if("iframe"!==a.tagName.toLowerCase()){var b=Nh(a,"videoid");b&&(b={videoId:b,width:Nh(a,"width"),height:Nh(a,"height")},new $h(a,b))}}
;F("YT.PlayerState.UNSTARTED",-1);F("YT.PlayerState.ENDED",0);F("YT.PlayerState.PLAYING",1);F("YT.PlayerState.PAUSED",2);F("YT.PlayerState.BUFFERING",3);F("YT.PlayerState.CUED",5);F("YT.get",function(a){return Jh[a]});
F("YT.scan",Mh);F("YT.subscribe",function(a,b,c){Kd.subscribe(a,b,c);Lh[a]=!0;for(var d in Jh)Jh.hasOwnProperty(d)&&Uh(Jh[d],a)});
F("YT.unsubscribe",function(a,b,c){Jd(a,b,c)});
F("YT.Player",$h);Z.prototype.destroy=Z.prototype.destroy;Z.prototype.setSize=Z.prototype.setSize;Z.prototype.getIframe=Z.prototype.na;Z.prototype.addEventListener=Z.prototype.addEventListener;$h.prototype.getVideoEmbedCode=$h.prototype.getVideoEmbedCode;$h.prototype.getOptions=$h.prototype.getOptions;$h.prototype.getOption=$h.prototype.getOption;
Kh.push(function(a){var b=a;b||(b=document);a=Ua(b.getElementsByTagName("yt:player"));var c=b||document;if(c.querySelectorAll&&c.querySelector)b=c.querySelectorAll(".yt-player");else{var d;c=document;b=b||c;if(b.querySelectorAll&&b.querySelector)b=b.querySelectorAll(".yt-player");else if(b.getElementsByClassName){var e=b.getElementsByClassName("yt-player");b=e}else{e=b.getElementsByTagName("*");var f={};for(c=d=0;b=e[c];c++){var g=b.className,h;if(h="function"==typeof g.split)h=0<=Pa(g.split(/\s+/),
"yt-player");h&&(f[d++]=b)}f.length=d;b=f}}b=Ua(b);H(Ta(a,b),ci)});
"undefined"!=typeof YTConfig&&YTConfig.parsetags&&"onload"!=YTConfig.parsetags||Mh();var di=B.onYTReady;di&&di();var ei=B.onYouTubeIframeAPIReady;ei&&ei();var fi=B.onYouTubePlayerAPIReady;fi&&fi();}).call(this);
